%------------- Log -----------
% SPEC: Template to generate blif.ys for yosys; Mosys
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 2019.5.28
% 1. setup
%------------- Log -----------
clc
clear
close

%-----------  Script example -----------%
% read_verilog adder.v
% hierarchy
% proc; opt; memory; opt; techmap; opt
% write_blif adder.blif

%-----------  Script parameters -----------%


%-----------  Design Information -----------%
OUTPUTFILE = 'run.do'; % OUTPUTFILE NAME
OPLOOP = 5; % Maximum number of optimization for ABC
% LUTK = [3 4 5 6 7 8 10 12]; % seven inputs 
LUTK = [3 4 5 6 7 8 10]; % six inputs 
% Input file list
INPUTFILE = {
'adder'; 
'arbiter';
'bar';
'cavlc';  
'ctrl';
'dec'; 
'div';
'hyp';
'i2c';  
'int2float';
'log2'; 
'max';
'mem_ctrl';
'mult';  
'priority';
'router'; 
'sin';
'sqrt';
'square';  
'voter'
};

%-----------  Print Control -----------% 
for i = 1:length(INPUTFILE)
    OUTPUTFILE = ['run_',INPUTFILE{i},'_gen_blif.ys']; % OUTPUTFILE NAME
    filenanme = OUTPUTFILE;
    % t = clock;
    % date = datestr(t);
    fid1 = fopen(filenanme,'w');
    fprintf(fid1,'read_verilog vlg/%s\n',[INPUTFILE{i},'.v']);
    fprintf(fid1,'hierarchy\n'); % hierarchy
    fprintf(fid1,'proc; opt; memory; opt; techmap; opt\n'); % process, optimal, memory, technology map
    fprintf(fid1,'write_blif blif_gate/%s\n',[INPUTFILE{i},'_gate.blif']); % write output
    fclose(fid1);
end

% ------------- Log -----------
% SPEC: Rank the signals
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 1-12-16
% 1. setup
% ------------- Extract information ------------
% sigStage: stage of each signal; .ss
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K = 3:16;
K = 3;
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
% '4bfa'
'fa'
};
%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%-----------  Extract Signals -----------%
inFolderPath = '.\epfl\';


%outFolderPath = '.\alu4\';
%outFolderPath = '.\apex2\';
%outFolderPath = '.\apex4\';
%outFolderPath = '.\ex5p\';
% outFolderPath = '.\pdc\';
% outFolderPath = '.\seq\';
%outFolderPath = '.\spla\';

%outFolderPath = '.\des\';
%outFolderPath = '.\misex3\';

% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUTSIG = 2;  % process luts signals
PLUTTAB = 3;  % process luts table
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Read and Print -----------%
for i = 1:length(INPUTFILE)
%for i = length(INPUTFILE):length(INPUTFILE)
%for i = 1:1
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];
    for j = 1:length(K)
    %for j = 10:length(K)
    %for j = 6:6
            siFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.si']
            suFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.su'];  % signal number
            ssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.ss'];  % signal stage
            fidSu = fopen(suFileName);
            fidSs = fopen(ssFileName,'w');
            totalSigNum = 0;
            while (~feof(fidSu))
                tline = fgetl(fidSu);
                str = tline;
                totalSigNum = totalSigNum + str2num(str);
            end
            % Extract stage information from .si
            sigStage = zeros(1,totalSigNum);   
            loopMax = 50;
            loopCnt = 1;
            updateCnt = 1;
            while((loopCnt < loopMax) && (updateCnt > 0) )
            %while((loopCnt < loopMax))
                updateCnt = 0;  
                rowCnt = 0;
                fidSi = fopen(siFileName);
                while (~feof(fidSi))
                    rowCnt = rowCnt + 1;
%                     if(rowCnt == 476)
%                         a = 1;
%                         sigStage(491) 
%                         sigStage(492)
%                         sigStage(493)
%                         sigStage(494)
%                         sigStage(495)
%                         sigStage(496)
%                         sigStage(497) 
%                         sigStage(22)
%                     end
                    tline = fgetl(fidSi);
                    str = tline;
                    % extract signal
                    key = '\w+';
                    tempSig = regexp(str,key,'match');
                    tempSigNum = [];
                    % transfer cell to num
                    for p = 1:length(tempSig) 
                        tempSigNum = [tempSigNum str2num(tempSig{p})];
                    end
                    % max stage of inputs
                    tempMax = 0;
                    for p = 1:length(tempSig)-1 
                        if(tempMax < sigStage(tempSigNum(p)))
                            tempMax = sigStage(tempSigNum(p));
                        end
                    end
                    % update stage of outputs
                    if (sigStage(tempSigNum(end)) < tempMax + 1)
                        sigStage(tempSigNum(end)) = tempMax + 1;
                        updateCnt = updateCnt + 1;
                    end
                    tempMax;
                    sigStage(tempSigNum(end));
                end
                updateCnt;
                loopCnt = loopCnt + 1;
                fclose(fidSi);
            end
            for p = 1:length(sigStage)
                fprintf(fidSs,'%d\n',sigStage(p));
            end
            fclose(fidSs);
    end
end

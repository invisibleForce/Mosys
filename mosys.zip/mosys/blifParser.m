% ------------- Log -----------
% SPEC: Parse Blif file and generate intermediate information
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 1-12-16
% 1. setup
% Date: 8-5-16
% 1. debug for add and mul benchmarks
% mosaic 2
% 1bit fa signal propagation
% ------------- Extract information ------------
% sigName: list of signal names; .sa
% sigNum: input, output, im;     .su 
% sigOut: the output is ON, OFF-one-minterm, OFF-multi-minterm; .so
% sigInfo: the labeled signals and ; .si
% lib: the labeled and rewritten LUTs; 
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K: input number of a lut
%K = [3 4 5 6 7 8 10 12 13 14 15 16];
% K = 3:16;
K = 3
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
%'adder'
% '4bfa'
'fa'
};
%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%-----------  Extract Signals -----------%
inFolderPath = '.\epfl\';
%inFolderPath = '.\mcnc\';
%inFolderPath = '.\add_mul\';
%outFolderPath = '.\alu4\';
%outFolderPath = '.\apex2\';
%outFolderPath = '.\apex4\';
%outFolderPath = '.\ex5p\';
% outFolderPath = '.\pdc\';
% outFolderPath = '.\seq\';
%outFolderPath = '.\spla\';

%outFolderPath = '.\des\';
%outFolderPath = '.\misex3\';
% outFolderPath = '.\adder\';


% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUT = 2;  % process luts
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Read and Print -----------%
% for i = 1:length(INPUTFILE)
for i = 1:1
    outFolderPath = ['.\',INPUTFILE{i},'\']
    for j = 1:length(K)
    %for j = 6:6
            %layoutFileName = [outFolderPath,'layout_',INPUTFILE{i},'.txt'];
            %fidLayout = fopen(layoutFileName,'w');
            %ssFileName =  [INPUTFILE{i},'_lut',num2str(K(j)),'.ss'];  % signal stage
            %logFileName = [INPUTFILE{i},'_lut',num2str(K(j)),'.log'];
            %inFileName = [inFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.blif']
            inFileName = [inFolderPath,INPUTFILE{i},'.blif']
            siFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.si'];
            saFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.sa'];
            suFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.su'];
            soFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.so'];
            snFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.sn'];
            miFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.mi'];
            libFileName =  [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.lib'];
            fidSi = fopen(siFileName,'w');
            fidSa = fopen(saFileName,'w');
            fidSu = fopen(suFileName,'w');
            fidSo = fopen(soFileName,'w');
            fidSn = fopen(snFileName,'w');
            fidMi = fopen(miFileName,'w');
            fidLib = fopen(libFileName,'w');
            fidInFile = fopen(inFileName);
            clk = fix(clock);       
            %------------ Global vars
            sigName = []; % Signal Names
            sigNum = [];  % Signal number in, out, im
            sigOut = [];  % Singal output type; ON-1minterm, ON-mminterm, OFF-1minterm, OFF-mminterm
            mintermNum = []; % Minterm numer
            %------------ Vars
            seg = CLN; 
            nIn = 0;
            nOut = 0;
            Phase = PIN;
            sigCnt = 0;
            rowCnt = 0;
            cline = {};
        while (~feof(fidInFile))
            tline = fgetl(fidInFile);
            str = tline
            rowCnt = rowCnt + 1;
            % extract words
            key = '\S*';
            word = regexp(str,key,'match');
            % complete line
            key = '\';
            if(strcmp(word{end},key)) % not finish
                cline = [cline word(1:end - 1)]; % remove '\' and attach to cline
            else % complete
                cline = [cline word]; % attach to cline
                if(Phase == PIN)
                    key = '.inputs';
                    if(strcmp(cline{1},key)) %start with inputs
                        cline = cline(2:end); % remove .inputs
                        sigNum = [sigNum length(cline)]; % input number
                        sigName = [sigName cline]; % sigName
                        tempOut = zeros(1,length(cline));
                        sigOut = [sigOut tempOut];
                        Phase = POUT;
                        sigNum;
                        sigName;
                        sigOut;
                    end
                elseif(Phase == POUT)
                    key = '.outputs';
                    if(strcmp(cline{1},key)) %start with .outputs
                        cline = cline(2:end); % remove .inputs
                        sigNum = [sigNum length(cline)]; % input number
                        sigName = [sigName cline]; % sigName
                        tempOut = zeros(1,length(cline));
                        sigOut = [sigOut tempOut];
                        Phase = PLUT;
                        flagLUT = 0;
                        sigNum;
                        sigName;
                        sigOut;
                    end
                elseif(Phase == PLUT)
                    if(strcmp(cline{1},'.names')) % .names
                        % update data for the previous table
                        if(flagLUT) 
                            for p = 1:length(sigName) 
                                if (length(regexp(sigName{p},sigLUT{end},'match')))
                                    if(tempOut == '1')  % ON Set
                                        sigOut(p) = OUTON;
                                    else
                                        if(mintermCnt == 1)
                                            sigOut(p) = OUTOFF1;
                                        else
                                            sigOut(p) = OUTOFFN;
                                        end
                                    end
                                end
                            end
                            mintermNum = [mintermNum mintermCnt];
                        end % update data for the previous table
                        % update flagLUT
                        flagLUT = 1;
                        
                        % update signals for current LUT
                        sigLUT = cline(2:end); % remove .names
                        if(length(sigLUT)) % extract signal names 
                            % update intermediate signals 
                            for p = 1:length(sigLUT)
                                missCnt = 0;
                                for q = 1:length(sigName)
                                    if (strcmp(sigName{q},sigLUT{p})) % already in sigName
                                        missCnt = missCnt + 0;
                                    else
                                        missCnt = missCnt + 1;
                                    end
                                end
                                if (missCnt == length(sigName))
                                    sigName = [sigName sigLUT(p)]; % add new signals, name
                                    sigCnt = sigCnt + 1;
                                    sigOut = [sigOut OUTON];       % add new signals, output type
                                end
                            end
                        end

                        % label the sigs and print them in .lib & .si
                        tempNum = [];
                        for p = 1:length(sigLUT)
                            for q = 1:length(sigName)
                                if (strcmp(sigName{q},sigLUT{p})) % already in sigName
                                    if(length(sigName{q}) == length(sigLUT{p}))
                                        tempNum = [tempNum, q];
                                    end
                                end
                            end
                        end
                        % print to .si
                        fprintf(fidSi,[repmat('%d ', 1, size(tempNum, 2)) '\n'],tempNum);
                        % print to .sn
                        fprintf(fidSn,'%d\n',length(sigLUT));
                        % fprintf(fid1,[repmat('%1.4f\t', 1, size(vlh_eas, 2)) '\n'], vlh_eas');
                        % print to .lib
                        fprintf(fidLib,['.names ' repmat('%d ', 1, size(tempNum, 2)) '\n'],tempNum);
                        mintermCnt = 0;
                        flagLUT = 1;
                    elseif(strcmp(cline{1},'.end')) % .end
                        for p = 1:length(sigName) 
                            if (strcmp(sigName{p},sigLUT{end}))
                                if(tempOut == '1')  % ON Set
                                    sigOut(p) = OUTON;
                                else
                                    if(mintermCnt == 1)
                                        sigOut(p) = OUTOFF1;
                                    else
                                        sigOut(p) = OUTOFFN;
                                    end
                                end
                            end
                       end
                       Phase = PIN;
                       mintermNum = [mintermNum mintermCnt];
                    else % LUT body
                        tempMinterm = tline(1:length(sigLUT)-1); % get minterm, n-input + 1-output, output is removed
                        tempMap = [];
                        % replace the symbols to mapping matrix
                        for p = 1:length(tempMinterm)
                            if(tempMinterm(p) == '-')
                                tempMap = [tempMap '00'];
                            elseif(tempMinterm(p) == '1')
                                tempMap = [tempMap '10'];
                            else % (tempMinterm(p) == '0')
                                tempMap = [tempMap '01'];
                            end
                        end
                        % print to .lib
                        %fprintf(fidLib,[repmat('%d ', 1, size(tempMap, 2)) '\n'],tempMap);
                        fprintf(fidLib,[repmat('%c', 1, size(tempMap, 2)) '\n'],tempMap);
                        % extract the signal output type (ON, OFF, s minterm, multi
                        % minterms)
                        tempOut = tline(length(sigLUT)+1);       % get output
                        mintermCnt = mintermCnt + 1;
                    end
                    
                end
                cline = {}; % clear cline
            end
        end
        
        % Print sigName of the blif
        for p = 1:length(sigName)
            fprintf(fidSa,[repmat('%c', 1, size(sigName{p}, 2)) '\n'],sigName{p});
        end
        % Print sigOut
        fprintf(fidSo,'%d\n',sigOut);
        % Print sigNum
        sigNum = [sigNum sigCnt];
        fprintf(fidSu,'%d\n',sigNum);
        % Print mintermNum
        fprintf(fidMi,'%d\n',mintermNum);
        fclose(fidInFile);
        fclose(fidLib);
        fclose(fidSi);
        fclose(fidSn);
        fclose(fidSa);
        fclose(fidSu);
        fclose(fidSo);
        fclose(fidMi);
    end
end

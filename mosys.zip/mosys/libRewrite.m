% ------------- Log -----------
% SPEC: Rewrite the lib by replacing the signal name with its order
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 2019.5.7
% 1. rewrite the lib consisting all luts
% ------------- Extract information ------------
% sigStage: stage of each signal; .ss
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K = 3:16;
K = 3
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
%'adder'
% '4bfa'
'fa'
};

%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%-----------  Extract Signals -----------%
% inFolderPath = '.\mcnc\';
% outFolderPath = '.\layout\';
% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUTSIG = 2;  % process luts signals
PLUTTAB = 3;  % process luts table
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Exploration -----------%
%----------- Read and Print -----------%

%for i = 1:length(INPUTFILE)
%for i = length(INPUTFILE):length(INPUTFILE)
for i = 1:1
    close all
    areaInfo = [];
    rowInfo = [];
    colInfo = [];
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];
    %for j = 11:length(K)
    for j = 1:1
    %for j = 6:6
        libFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.lib'];
        ssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.ss'];  % signal stage
        suFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.su'];  % signal number
        sodFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.sod'];  % signal order
        rwlibFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwlib']; % rewritten lib 
        rwssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwss']; % rewritten stage of each signal
        rwmiFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwmi']; % rewritten minterm numbers of each lut 
        stFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.st'];  % statistics
        fidSs = fopen(ssFileName);
        fidSu = fopen(suFileName);
        fidLib = fopen(libFileName);
        fidSod = fopen(sodFileName);
        fidRwlib = fopen(rwlibFileName, 'w');
        fidRwss = fopen(rwssFileName, 'w');
        fidRwmi = fopen(rwmiFileName, 'w');
        % ------------------------------ 
        % Read inNum from .su
        % ------------------------------
        rdCnt = 1;
        while (~feof(fidSu))
            tline = fgetl(fidSu);
            str = tline;
            if(rdCnt == 1)
                inNum = str2num(str);
            elseif(rdCnt == 2)
                outNum = str2num(str);
            elseif(rdCnt == 3)
                imNum = str2num(str);
            end
            rdCnt = rdCnt + 1;
        end
        % ------------------------------ 
        % Read stageNum from .ss
        % ------------------------------
        sigStage = [];
        while (~feof(fidSs))
            tline = fgetl(fidSs);
            str = tline;
            sigStage = [sigStage str2num(str)];
        end
        stageNum = max(sigStage)
        % ------------------------------ 
        % Extract sigOrder from .sod
        % ------------------------------
        sigOrder = [];
        while (~feof(fidSod))
            tline = fgetl(fidSod);
            str = tline;
            % extract numbers
            key = '\d+';
            word = regexp(str,key,'match')
            sodLine = []; 
            for k = 1:length(word)
                sodLine = [sodLine, str2num(word{k})];
            end
            sigOrder = [sigOrder; sodLine];
        end
        'sigOrder'
        sigOrder
        % ------------------------------ 
        % Read the whole lib in a cell array
        % ------------------------------
        lib = {};
        lineCnt = 1;
        lutAddr = [];
        lutOutput = [];
        while (~feof(fidLib))
            tline = fgetl(fidLib);
            str = tline;
            % start of the lut
            key = '.names';
            if(length(regexp(str,key,'match'))) % find a lut
                % store the lutAddr
                lutAddr = [lutAddr lineCnt];
                % obtain the output singal of the lut
                key = '\d+';
                word = regexp(str,key,'match');
                lutOutput = [lutOutput str2num(word{end})];
            end
            lib{lineCnt} = str;
            lineCnt = lineCnt + 1; % update the line counter
        end        
        lib
        lutOutput
        lutAddr
        % ----------------
        % Lut Length
        % ----------------
        lutLen = []
        for tempCnt = 1:length(lutAddr)
            if tempCnt == length(lutAddr)
                lutLen = [lutLen (length(lib) + 1 - lutAddr(tempCnt))];
            else
                lutLen = [lutLen (lutAddr(tempCnt + 1) - lutAddr(tempCnt))];
            end
        end
        lutLen
        % ------------------------------ 
        % Rewrite the signal stage for the sorted signals
        % ------------------------------
        for stageCnt = 0:stageNum
            for sigCnt = 1:length(sigOrder)
                if sigOrder(sigCnt,2) == stageCnt
                    fprintf(fidRwss,'%d\n',sigOrder(sigCnt, 2));
                end
            end
        end
        % ------------------------------ 
        % Replace signal name with signal order
        % ------------------------------
        for lutCnt = 1:length(lutAddr)
            % print lut head
            str = lib{lutAddr(lutCnt)};
            key = '\d+';
            word = regexp(str,key,'match');
            lutHead = '.names ';
            for tempCnt = 1:length(word)
                tempSig = str2num(word{tempCnt});
                tempSig = sigOrder(tempSig, 1);
                lutHead = [lutHead,num2str(tempSig),' '];
            end
            lib{lutAddr(lutCnt)} = lutHead;    
        end
        lib
        % ------------------------------ 
        % Rewrite the lib based on their signals
        % ------------------------------
        for sigCnt = (inNum+1):length(sigOrder)
            for lutCnt = 1:length(lutAddr)
                if sigOrder(lutOutput(lutCnt),1) == sigCnt
                    fprintf(fidRwmi,'%d\n',lutLen(lutCnt)-1);
                    for tempCnt = lutAddr(lutCnt):(lutAddr(lutCnt) + lutLen(lutCnt) - 1)
                        fprintf(fidRwlib,'%s\n',lib{tempCnt});
                    end
                end
            end
        end
        fclose(fidLib);
        fclose(fidSod);
        fclose(fidRwlib);
        fclose(fidRwss);
        fclose(fidRwmi);
    end   
end

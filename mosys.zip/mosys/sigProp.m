% ------------- Log -----------
% SPEC: Propagate the signal probability to the whole mapping matrix
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 05.05.19
% 1. rin - ini the signal probability matrix (spm)
% 2. cfm - copy inputs to minterms 
% ------------- Extract information ------------
% sigProb: signal probility; .spm
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K = 3:16;
K = 3
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
%'adder'
'4bfa'
% 'fa'
};

%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%----------- Prob -------------------%
P1 = 0.5        % probability of each signal to be logic 1
P0 = 1 - P1     % probability of each signal to be logic 0
%-----------  Extract Signals -----------%
% inFolderPath = '.\mcnc\';
% outFolderPath = '.\layout\';
% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUTSIG = 2;  % process luts signals
PLUTTAB = 3;  % process luts table
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Exploration -----------%
%----------- Stat variables -----------%
stInNum = 1
stOutNum = 2
stImNum = 3
stLutNum = 4
stRowNum = 5
stColNum = 6
stDeviceNum = 7
stStageNum = 8
stMemNum = 9
%----------- Read and Print -----------%

%for i = 1:length(INPUTFILE)
%for i = length(INPUTFILE):length(INPUTFILE)
for i = 1:1
    close all
    areaInfo = [];
    rowInfo = [];
    colInfo = [];
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];
    %for j = 11:length(K)
    for j = 1:1
    %for j = 6:6
%         libFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.lib']
        rwssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwss'];  % signal stage
        snFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.sn'];  % minterms of each stage
%         suFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.su'];  % signal number
%         soFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.so'];  % signal output
%         miFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.mi'];  % minterm info
        xlFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.xl'];  % xbar layout
        stFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.st'];  % statistics
        spmFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.spm'];  % signal probability matrix
        spmgFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'_spm.png'];  % hotmap of the spm
%         fidLib = fopen(libFileName);
        fidSs = fopen(rwssFileName);
        fidSn = fopen(snFileName);
%         fidSu = fopen(suFileName);
%         fidSo = fopen(soFileName);
%         fidMi = fopen(miFileName);
        fidXl = fopen(xlFileName);
        fidSt = fopen(stFileName);
        fidSpm = fopen(spmFileName,'w');
        %--------------------------
        % Read xl into a matrix
        %--------------------------
        xl = [];
        while (~feof(fidXl))
            tline = fgetl(fidXl);
            str = tline
            % extract numbers
            key = '\d';
            word = regexp(str,key,'match')
            xlLine = []; 
            for k = 1:length(word)
                xlLine = [xlLine, str2num(word{k})];
            end
            xlLine
            xl = [xl; xlLine];
        end
        %--------------------------
        % assign xl to spm
        %--------------------------
        spm = xl
        [xlRowNum xlColNum] = size(xl);
        %--------------------------
        % Read signal stage
        %--------------------------
        ss = [];
        while (~feof(fidSs))
            tline = fgetl(fidSs);
            ss = [ss, str2num(tline)];
        end
        ss
        % calculate the max stage
        stageTotal = max(ss)
        %--------------------------
        % Read st
        %--------------------------
        st = [];
        while (~feof(fidSt))
            tempNum = 0
            tline = fgetl(fidSt);
            str = tline;
            % extract numbers
            key = '\d';
            word = regexp(str,key,'match')
            for tempCnt = length(word):-1:1
                tempNum = tempNum + str2num(word{tempCnt})*10^(length(word) - tempCnt)
            end
            st = [st tempNum];
        end
        st
        %--------------------------
        % Read sn; num of minterms for each lut
        %--------------------------
        sn = [];
        while (~feof(fidSn))
            tempNum = 0
            tline = fgetl(fidSn);
            str = tline;
            % extract numbers
            key = '\d';
            word = regexp(str,key,'match')
            for tempCnt = length(word):-1:1
                tempNum = tempNum + str2num(word{tempCnt})*10^(length(word) - tempCnt)
            end
            sn = [sn tempNum];
        end
        sn
        %------------ RIN --------------
        % RIN: update all the primary inputs with the probability
        for k = 1:xlColNum
            if spm(1,k) == 1
                if mod(k,2) == 0 % 
                    spm(1,k) = P0;
                else
                    spm(1,k) = P1;
                end
            end
        end
        'RIN:'
        spm 
        %------------ RIN --------------
        %------------ CFM --------------
        for stageCnt = 1:stageTotal
            stageCnt;
            % CFM: Copy, update all the signals
            % All the signals whose stage is less than stageCnt
            % scan the signal
            for colCnt = 1:xlColNum % CFM
                colCnt;
                if ss(ceil(colCnt/2)) < stageCnt % stageSig < stageCnt
                    % primary inputs
                    if colCnt <= 2*st(stInNum) % update 
                        % update all
                        for rowCnt = 2:xlRowNum % without the IL
                            if xl(rowCnt,colCnt) == 1
                                spm(rowCnt,colCnt) = spm(1,colCnt);
                            end
                        end
                    else % intermediate signals
                        % only update the ones 
                        % search the '11' in both the primary and negated signals
                        propFlag = 0;
                        for rowCnt = 2:xlRowNum % without the IL
                            % update the signals
                            if propFlag
                                if xl(rowCnt,colCnt)
                                    spm(rowCnt,colCnt) = spm(1,colCnt);
                                end
                            end
                            % detect where to start propagate the signals
                            if mod(colCnt,2) == 0 % even
                                if xl(rowCnt,colCnt) == 1 && xl(rowCnt,colCnt - 1) == 1
                                    propFlag = 1;
                                end
                            else % odd
                                if xl(rowCnt,colCnt) == 1 && xl(rowCnt,colCnt + 1) == 1
                                    propFlag = 1;
                                end
                            end
                        end
                    end
                end
            end % CFM  
            'CFM Result'
            spm % cfm
            %------------ CFM --------------
            %------------ EVM, GER, INR --------------
            % for each negation of primary output and intermediate signal
            startSig = 2*st(stInNum) + 2 % filter the input signals
            for colCnt = startSig : 2 : xlColNum % EVM
                % if stageSig == stageCnt
                if ss(ceil(colCnt/2)) == stageCnt
                    % NAND gates before the OL
                    rowCnt = 2 % start of the NAND
                    % EVM, NAND & GER, AND
                    tempProdAND = 1
                    while(~(xl(rowCnt, colCnt) && xl(rowCnt, colCnt - 1))) % find OL pattern; 11
                        if xl(rowCnt, colCnt)   % NAND gate
                            tempProdNAND = 1
                            tempIdx = find(xl(rowCnt, :)) % all the inputs of the NAND gate
                            for tempCnt = 1:length(tempIdx)
                                if tempIdx(tempCnt) ~= colCnt
                                    tempProdNAND = tempProdNAND * spm(rowCnt, tempIdx(tempCnt)) % calculate probability of the NAND gate output
                                end
                            end
                            % update the spm element
                            spm(rowCnt, colCnt) = 1 - tempProdNAND;
                            tempProdAND = tempProdAND * (1 - tempProdNAND)
                        end
                        rowCnt = rowCnt + 1
                    end
                    % GER, AND, update spm
                    spm(rowCnt, colCnt) = tempProdAND;
                    % INR, at OL
                    spm(rowCnt, colCnt - 1) = 1 - tempProdAND;
                    % update the probability of the primary output/intermediate signals
                    spm(1, colCnt - 1) = spm(rowCnt, colCnt - 1); % primary signal
                    spm(1, colCnt) = spm(rowCnt, colCnt); % negation of the signal
                end
            end 
            spm % EVM, GER, INR
            %------------ EVM, GER, INR --------------
        end % stage loop
        % print spm
        for p = 1:xlRowNum
            fprintf(fidSpm,[repmat('%1.4f ', 1, size(spm(p,:), 2)) '\n'],spm(p,:));
        end
        % plot spm graph
        figure
        colormap('hot');   % set colormap
        imagesc(spm);        % draw image and scale colormap to values range
        % imagesc(ACSST);        % draw image and scale colormap to values range
        colorbar;          % show color scale
        saveas(gcf,spmgFileName);
%         fclose(fidLib);
        fclose(fidSs);
        fclose(fidSn);
%         fclose(fidSu);
%         fclose(fidSo);
%         fclose(fidMi);
        fclose(fidXl);
        fclose(fidSt);
        fclose(fidSpm);
    end
end

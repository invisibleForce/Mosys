%------------- Log -----------
% SPEC: Estimate the performance of the design
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 9-12-16
% 1. setup
% Date: 19.05.06
% 1. support the signal-propagation based power consumption
% 1.1 RIN - program the primary inputs
% 1.2 CFM
% 1.3 EVM
%------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation

%-----------  Script parameters -----------%


%-----------  Design Information -----------%
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% K = 3:16;
K = 3

% epfl benchmark
INPUTFILE = {
% 'adder'
'4bfa'
% 'fa'
};

%-----------  Parameters -----------% 
% General
kilo = 1e3      %unit
micro = 1e-6    % micro
% Technology
F = 90e-3; % Tech node, 90nm, unit um
F2 = F*F; % area of F^2,  , unit um^2
Tsw = 0.2;             % Switching time of a memristor, ns
RCF2 = 2.06e-17/1e-9;  % Unit delay, ns
RL = 200 * kilo             % Low resistance 200kOhm
rHL = 7  * kilo             % RH/RL
rDH = 50                    % RD/RH
rSL = 10                    % RS/RL
RH = rHL * RL               % High resistance
RD = rDH * RH               % Disabled resistance
RS = rSL * RL               % Reference resistor
% control voltage
VW = 2.1                    % write voltage
VH = 1.05                   % half-select voltage
VG = 0                      % ground voltage
% Mem
A1r = 4*F2; % area of a memristor in xbar

% Gate
Dbuf = 77e-12/1e-9;    % Delay of a normal buffer, SAED, NBUFFX2
Abuf = 5.5296;         % area of a buffer,  unit um^2

% Driver
NCTRL = 2;

% Ctrller
% For the xbar consisting 1 to 25 stage(s) 
% Area of the core ctrl, um^2
ActrlCore = [
434;
610;
810;
925;
1139;
1230;
1335;
1453;
1655;
1780;
1858;
1960;
2063;
2172;
2367;
2390;
2600;
2765;
2871;
2701;
3059;
2928;
3248;
3107;
3264;
]; 

% Delay of the core ctrl, ns 
DctrlCore = [
1.335;
1.301;
1.353;
1.328;
1.256;
1.386;
1.366;
1.353;
1.256;
1.256;
1.256;
1.301;
1.256;
1.346;
1.341;
1.339;
1.277;
1.344;
1.350; %19
1.277;
1.277;
1.277;
1.277;
1.344;  
1.277; %25
]; 


for i = 1:length(INPUTFILE)
%for i = 1:1
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];   
    peFileName = [outFolderPath,INPUTFILE{i},'.pe'];  % performance for all Ks
    fidPe = fopen(peFileName,'w');
    totalAreaInfo = [];
    totalDelayInfo = [];
    for j = 1:length(K)
    %for j = 1:1
        % --------------- Input files -----------
        ssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwss'];  % signal stage, rewritten
        miFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwmi'];  % minterm # of each lut, rewritten
        stFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.st'];  % statistics
        siFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.si'];  % signal list of each lut
        xlFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.xl'];  % xbar layout
        spmFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.spm'];  % signal probability matrix
        fidSs = fopen(ssFileName);
        fidMi = fopen(miFileName);
        fidSt = fopen(stFileName);
        fidSi = fopen(siFileName);
        fidXl = fopen(xlFileName);
        fidSpm = fopen(spmFileName);
        
        % ---------------- Parameter extraction ------------
        % Xbar

        % @.st
        % inNum
        % outNum
        % imNum        
        % deviceNum
        % memNum
        % stageNum
        % rowNum
        % colNum
        while (~feof(fidSt))
            tline = fgetl(fidSt);
            str = tline;
            % inNum
            key = '.inNum';
            if(length(regexp(str,key,'match'))) % extract inNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                inNum = str2num(tempStr{1}); 
            end
            % outNum
            key = '.outNum';
            if(length(regexp(str,key,'match'))) % extract outNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                outNum = str2num(tempStr{1}); 
            end
            % imNum
            key = '.imNum';
            if(length(regexp(str,key,'match'))) % extract imNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                imNum = str2num(tempStr{1}); 
            end
            % deviceNum
            key = '.deviceNum';
            if(length(regexp(str,key,'match'))) % extract deviceNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                deviceNum = str2num(tempStr{1}); 
            end
            % memNum
            key = '.memNum';
            if(length(regexp(str,key,'match'))) % extract memNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                memNum = str2num(tempStr{1}); 
            end
            % stageNum
            key = '.stageNum';
            if(length(regexp(str,key,'match'))) % extract stageNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                stageNum = str2num(tempStr{1}); 
            end
            % rowNum
            key = '.rowNum';
            if(length(regexp(str,key,'match'))) % extract rowNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                rowNum = str2num(tempStr{1}); 
            end
            % colNum
            key = '.colNum';
            if(length(regexp(str,key,'match'))) % extract colNum
                key = '\d+';
                tempStr = regexp(str,key,'match');
                colNum = str2num(tempStr{1});
            end
        end
        
        % --- Read in signal stage ------------
        sigStage = [];
        while (~feof(fidSs))
            tline = fgetl(fidSs);
            str = tline;
            sigStage = [sigStage str2num(str)];
        end
        length(sigStage);
        % ----- Extract signal number in each stage -----    
        sigNum = zeros(1,stageNum + 1);
        for p = 1:length(sigStage)
            sigNum(sigStage(p)+1) = sigNum(sigStage(p)+1) + 1;  % due to the stage starts from 0 to stageNum - 1
        end
        sigNum;
        % --- Read in minterm per lut ------------
        mtLut = [];
        while (~feof(fidMi))
            tline = fgetl(fidMi);
            str = tline;
            mtLut = [mtLut str2num(str)];
        end
        length(mtLut);
        % ----- Extract stage for each lut -----
        lutStage = sigStage(inNum + 1:end);
        % ----- Calculate row stage -----
        rowStage = [];
        % primary input row
        rowStage = [rowStage 0];
        % other rows
        for lutCnt = 1:length(lutStage)
            for mtCnt = 1:(mtLut(lutCnt) + 1)
                rowStage = [rowStage lutStage(lutCnt)];
            end
        end
        rowStage
        size(rowStage)
%         lutStage = [];
%         while (~feof(fidSi))
%             tline = fgetl(fidSi);
%             str = tline;
%             key = '\d+';
%             tempStr = regexp(str,key,'match');
%             tempOut = str2num(tempStr{end});
%             lutStage = [lutStage sigStage(tempOut)];
%         end
%         length(lutStage);
        % ----- Extract minterm number in each stage -----    
        mtNum = zeros(1,stageNum);
        for p = 1:length(lutStage)
            mtNum(lutStage(p)) = mtNum(lutStage(p)) + mtLut(p);  % due to the stage starts from 0 to stageNum - 1
        end
        lutStage
        % ----- Extract lut number in each stage ----- 
        lutNum = zeros(1,stageNum);
        for p = 1:length(lutStage)
            lutNum(lutStage(p)) = lutNum(lutStage(p)) + 1;  % due to the stage starts from 0 to stageNum - 1
        end
        length(lutNum);
        
        %--------------------------
        % Read xl into a matrix
        %--------------------------
        xl = [];
        while (~feof(fidXl))
            tline = fgetl(fidXl);
            str = tline;
            % extract numbers
            key = '\d';
            word = regexp(str,key,'match');
            xlLine = []; 
            for k = 1:length(word)
                xlLine = [xlLine, str2num(word{k})];
            end
%             xlLine
            xl = [xl; xlLine];
        end
        xl
%         [xlRowNum xlColNum] = size(xl)
        %--------------------------
        % Read spm into a matrix
        %--------------------------
        spm = [];
        while (~feof(fidSpm))
            tline = fgetl(fidSpm);
            str = tline;
            % extract numbers
            key = '\d.\d+';
            word = regexp(str,key,'match');
            spmLine = []; 
            for k = 1:length(word)
                spmLine = [spmLine, str2num(word{k})];
            end
            spmLine;
            spm = [spm; spmLine];
        end
        spm
        
        %------------------ Power Estimation ------------
        pRIN = 0;
        pCFM = 0;
        pEVM = 0;
        pGER = 0;
        pINR = 0;
        pINA = 0;
        % RIN; program all primary inputs
        % for each signal (column)
        for colCnt = 1:colNum
            for rowCnt = 1:rowNum
                if colCnt <= 2 * inNum % primary inputs
                    if rowCnt == 1  % IL
                        vr = VG;  % row voltage
                        % input is 1; RH, no switch
                        vc = VG;
                        r = RH;
                        p1 = (vr - vc)^2 / r;
                        % input is 0; RL, switch
                        vc = VW;
                        r = RH; % BSW, before switch
                        p0bsw = (vr - vc)^2 / r;
                        r = RL; % ASW, after switch
                        p0asw = (vr - vc)^2 / r;
                        p0 = 0.5 * (p0bsw + p0asw);
                        p = spm(rowCnt, colCnt) * p1 + (1 - spm(rowCnt, colCnt)) * p0;
                    else % other rows
                        vr = VH;  % row voltage
                        if xl(rowCnt, colCnt) % active device
                            r = RH;
                        else % disabled device
                            r = RD;
                        end
                        % input is 1; RH, no switch
                        vc = VG;
                        p1 = (vr - vc)^2 / r;
                        % input is 0; RL, switch
                        vc = VW;
                        p0 = (vr - vc)^2 / r;
                        p = spm(rowCnt, colCnt) * p1 + (1 - spm(rowCnt, colCnt)) * p0;
                    end
                else % primary outputs / intermediate signals
                    if rowCnt == 1
                        vr = VG;
                        vc = VH;
                        if xl(rowCnt, colCnt) % active device
                            r = RH;
                        else % disabled device
                            r = RD;
                        end
                        p = (vr - vc)^2 / r;
                    else
                        vr = VH;
                        vc = VH;
                        if xl(rowCnt, colCnt) % active device
                            r = RH;
                        else % disabled device
                            r = RD;
                        end
                        p = (vr - vc)^2 / r;
                    end
                end   
                pRIN = pRIN + p;  % accumulate the power consumption
            end
        end % RIN
        % power conumption of Rs
        % RS attached to columns
        for colCnt = 1:colNum
            if colCnt <= 2 * inNum % primary inputs
                vr = VG;  % row voltage
                r = RS;
                % input is 1; RH, no switch
                vc = VG;
                p1 = (vr - vc)^2 / r;
                % input is 0; RL, switch
                vc = VW;
                p0 = (vr - vc)^2 / r;
                p = spm(1, colCnt) * p1 + (1 - spm(1, colCnt)) * p0;
            else
                vr = VG;
                vc = VH;
                r = RS;
                p = (vr - vc)^2 / r;
            end
            pRIN = pRIN + p;  % accumulate the power consumption
        end
        % RS attached to rows
        for rowCnt = 1:rowNum
            if rowCnt == 1 % IL
                vr = VG;  % row voltage
                vc = VG;
                r = RS;
                p = (vr - vc)^2 / r;
            else % other rows
                vr = VH;
                vc = VG;
                r = RS;
                p = (vr - vc)^2 / r;
            end
            pRIN = pRIN + p;  % accumulate the power consumption
        end
        pRIN;
        
        for stageCnt = 1:stageNum
            stageCnt;
            %------------ CFM --------------
            % calculate the conductance
            % >n-1, >n-1: RH/RD
            % >n-1, =n-1: nsw: RH, bsw: RH, asw: RL; RD of xl(i,j)=0
            % otherwise: Ravg/RD
            gnsw = ones(rowNum, colNum) * (1/RD);
            gbsw = ones(rowNum, colNum) * (1/RD);
            gasw = ones(rowNum, colNum) * (1/RD);
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum % skip the IL
                for colCnt = 1:colNum
                    if (rowStage(rowCnt) > stageCnt - 1) && (sigStage(ceil(colCnt/2)) > stageCnt - 1) % (>n-1,>n-1)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = 1/RH; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RH; % asw
                        end
                    elseif (rowStage(rowCnt) > stageCnt - 1) && (sigStage(ceil(colCnt/2)) == stageCnt - 1) % (>n-1,=n-1)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = 1/RH; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt - 1) && (sigStage(ceil(colCnt/2)) == stageCnt - 1) % (=n-1,=n-1)
                        if xl(rowCnt, colCnt)
                            if rowCnt == 1 % IL
                                gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                gbsw(rowCnt, colCnt) = 1/RL; % bsw
                                gasw(rowCnt, colCnt) = 1/RL; % asw
                            else
                                if mtCnt < mtLut(lutCnt) + 1 % mt
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                                    gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                                else % ol
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = 1/RL; % bsw
                                    gasw(rowCnt, colCnt) = 1/RL; % asw
                                end
                            end
                        end
                    else % all the other parts
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL;
                            gbsw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL;
                            gasw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL;
                        end
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            gnsw
            gbsw
            gasw
            % calculate vr          
            vr = ones(1, rowNum) * VG;
            for rowCnt = 1:rowNum
                if rowStage(rowCnt) == stageCnt - 1
                    vr(rowCnt) = VW;
                elseif rowStage(rowCnt) > stageCnt - 1
                    vr(rowCnt) = VG;
                else % < stageCnt - 1
                    vr(rowCnt) = VH; % free
                end 
            end
            vr
            
            % calculate vc
            vcnsw = ones(1, colNum) * VH;
            vcbsw = ones(1, colNum) * VH;
            vcasw = ones(1, colNum) * VH;
            for colCnt = 1:colNum % only calculate the voltage of the floating wires; the first row is skipped
                if sigStage(ceil(colCnt/2)) == stageCnt - 1
                   % nsw
                   gTemp = gnsw(:, colCnt);
                   vTemp = vr;
                   vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                   vcnsw(colCnt) = vxTemp;
                   % bsw
                   gTemp = gbsw(:, colCnt);
                   vTemp = vr;
                   vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                   vcbsw(colCnt) = vxTemp;
                   % asw
                   gTemp = gasw(:, colCnt);
                   vTemp = vr;
                   vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                   vcasw(colCnt) = vxTemp;
                end 
            end
            vcnsw
            vcbsw
            vcasw
            % Calculate the conductance in current stage and state
            % power
            % cells
            mtCnt = 1;
            lutCnt = 1;
            % cells
            for rowCnt = 1:rowNum
                for colCnt = 1:colNum
                    rowCnt;
                    colCnt;
                    mtCnt;
                    lutCnt;
                    if sigStage(ceil(colCnt/2)) == stageCnt - 1 % it consists of non-deterministic voltage
                        % lookup the output signal of the lut and its
                        % prob
                        Pout1 = spm(1,colCnt);
                        pDeviceNsw = (vr(rowCnt) - vcnsw(colCnt))^2 * gnsw(rowCnt, colCnt);
                        pDeviceBsw = (vr(rowCnt) - vcbsw(colCnt))^2 * gbsw(rowCnt, colCnt);
                        pDeviceAsw = (vr(rowCnt) - vcasw(colCnt))^2 * gasw(rowCnt, colCnt);
                        pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw);
                        pCFM = pCFM + pDevice
                    else
                        pDevice = (vr(rowCnt) - vcnsw(colCnt))^2 * gnsw(rowCnt, colCnt)
                        pCFM = pCFM + pDevice
                    end
                end
                % update mtCnt and LutCnts
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            pCFM;
            % RS
            % row
            rowGS = ones(1, rowNum) * (1/RS)
            pRSrow = vr.^2 .* rowGS;
            pRSrow = sum(pRSrow)
            pCFM = pCFM + pRSrow
            % col
            colGS = ones(1, colNum) * (1/RS);
            pRScol = 0;
            for colCnt = 1:colNum
                if sigStage(ceil(colCnt/2)) == stageCnt - 1 % it consists of non-deterministic voltage
                    % lookup the output signal of the lut and its
                    % prob
                    Pout1 = spm(1,colCnt);
                    pDeviceNsw = vcnsw(colCnt)^2 * colGS(colCnt);
                    pDeviceBsw = vcbsw(colCnt)^2 * colGS(colCnt);
                    pDeviceAsw = vcasw(colCnt)^2 * colGS(colCnt);
                    pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw);
                    pRScol = pRScol + pDevice;
                else
                    pDevice = vcnsw(colCnt)^2 * colGS(colCnt);
                    pRScol = pRScol + pDevice;
                end
            end
            pRScol;
            pCFM = pCFM + pRScol;
            
            
            %------------ EVM --------------
            % calculate the conductance
            % nine regions divided by their stage numbers
            % denoted by (row,col)
            % (<n,<n): avg/disabled
            % (<n,=n): disabled
            % (<n,>n): disabled
            % (=n,<n): avg/diabled
            % (=n,=n): case-related/diabled
            % (=n,>n),(>n,<n),(>n,=n),(>n,>n): disabled
            gnsw = ones(rowNum, colNum) * (1/RD);
            gbsw = ones(rowNum, colNum) * (1/RD);
            gasw = ones(rowNum, colNum) * (1/RD);
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum % skip the IL
                for colCnt = 1:colNum
                    if (rowStage(rowCnt) < stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (<n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL; % bsw
                            gasw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (=n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(1, colCnt)/RH + (1-spm(1, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RH; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) == stageCnt)% (=n,=n)
                        if xl(rowCnt, colCnt)
                            if mtCnt < mtLut(lutCnt) + 1 % mt
                                gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                gasw(rowCnt, colCnt) = 1/RL; % asw
                            else % ol
                                gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                gasw(rowCnt, colCnt) = 1/RH; % asw
                            end
                        end
                    else % all the other cases
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = 1/RH; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RH; % asw
                        end
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            gnsw
            gbsw
            gasw
            % calculate vc, column voltage - deteministic
            vc = ones(1, colNum) * VH;
            for colCnt = 1:colNum
                if sigStage(ceil(colCnt/2)) == stageCnt
                    vc(colCnt) = VW;
                end 
            end
            vc
            % calculate vr
            vrnsw = ones(1, rowNum) * VH;
            vrbsw = ones(1, rowNum) * VH;
            vrasw = ones(1, rowNum) * VH;
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 2:rowNum % only calculate the voltage of the floating wires; the first row is skipped
                if rowStage(rowCnt) == stageCnt
                   if (mtCnt <= mtLut(lutCnt))
                       % nsw
                       gTemp = gnsw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrnsw(rowCnt) = vxTemp;
                       % bsw
                       gTemp = gbsw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrbsw(rowCnt) = vxTemp;
                       % asw
                       gTemp = gasw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrasw(rowCnt) = vxTemp;
                   end
                   if mtCnt < mtLut(lutCnt) + 1
                       mtCnt = mtCnt + 1;
                   else
                       mtCnt = 1;
                       lutCnt = lutCnt + 1;
                   end
                end 
            end
            vrnsw
            vrbsw
            vrasw            
            % calculate power consumption
            mtCnt = 1;
            lutCnt = 1;
            % cells
            for rowCnt = 1:rowNum
                for colCnt = 1:colNum
                    rowCnt;
                    colCnt;
                    mtCnt;
                    lutCnt;
                    if rowStage(rowCnt) == stageCnt % it consists of non-deterministic voltage
                        if rowCnt >= 2  % lutStage
                            % mt
                            if mtCnt <= mtLut(lutCnt)
                                % lookup the output signal of the lut and its
                                % prob
                                Pout1 = spm(rowCnt,(lutCnt + inNum) * 2)
                                pDeviceNsw = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                                pDeviceBsw = (vrbsw(rowCnt) - vc(colCnt))^2 * gbsw(rowCnt, colCnt)
                                pDeviceAsw = (vrasw(rowCnt) - vc(colCnt))^2 * gasw(rowCnt, colCnt)
                                pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                                pEVM = pEVM + pDevice
                            % ol
                            else
                                pDevice = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                                pEVM = pEVM + pDevice
                            end
                        end
                    else
                        pDevice = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                        pEVM = pEVM + pDevice
                    end
                end
                % update mtCnt and LutCnts
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1
                    else
                        mtCnt = 1
                        lutCnt = lutCnt + 1
                    end
                end
            end
            pEVM;
            % RS
            % col
            colGS = ones(1, colNum) * (1/RS)
            pRScol = vc.^2 .* colGS
            pEVM = pEVM + sum(pRScol)
            % row
            rowGS = ones(1, rowNum) * (1/RS);
            pRSrow = 0;
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum
                if rowStage(rowCnt) == stageCnt % it consists of non-deterministic voltage
                    if rowCnt >= 2  % lutStage
                        % mt
                        if mtCnt <= mtLut(lutCnt)
                            % lookup the output signal of the lut and its
                            % prob
                            Pout1 = spm(rowCnt,(lutCnt + inNum) * 2)
                            pDeviceNsw = vrnsw(rowCnt)^2 * rowGS(rowCnt)
                            pDeviceBsw = vrbsw(rowCnt)^2 * rowGS(rowCnt)
                            pDeviceAsw = vrasw(rowCnt)^2 * rowGS(rowCnt)
                            pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                            pRSrow = pRSrow + pDevice;
                        else
                            pDevice = vrnsw(rowCnt)^2 / RS
                            pRSrow = pRSrow + pDevice;
                        end
                    else 
                        pDevice = vrnsw(rowCnt)^2 / RS
                        pRSrow = pRSrow + pDevice;
                    end
                else
                    pDevice = vrnsw(rowCnt)^2 / RS
                    pRSrow = pRSrow + pDevice;
                end
                % update mtCnt and LutCnts
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1
                    else
                        mtCnt = 1
                        lutCnt = lutCnt + 1
                    end
                end
            end
            pEVM = pEVM + pRSrow;
            
            
            %------------ GER --------------
            % calculate the conductance
            % nine regions divided by their stage numbers
            % denoted by (row,col)
            % (<n,<n): avg/disabled
            % (<n,=n): disabled
            % (<n,>n): disabled
            % (=n,<n): avg/diabled
            % (=n,=n): case-related/diabled
            % within (=n,=n) field, it can be further divide into four
            % subfields
            % (mt,x) - RD, (mt, xbar) - case related: nsw - all RH, bsw/asw
            % - Ravg 
            % (ol, x) - RH, (ol, xbar) - case realted: nsw - RH, bsw - RH,
            % asw - RL
            % (=n,>n),(>n,<n),(>n,=n),(>n,>n): disabled
            gnsw = ones(rowNum, colNum) * (1/RD);
            gbsw = ones(rowNum, colNum) * (1/RD);
            gasw = ones(rowNum, colNum) * (1/RD);
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum % skip the IL
                for colCnt = 1:colNum
                    if (rowStage(rowCnt) < stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (<n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                            gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (=n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                            gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) == stageCnt)% (=n,=n)
                        if xl(rowCnt, colCnt)
                            if mtCnt < mtLut(lutCnt) + 1 % mt
                                if mod(colCnt, 2)==0  % odd, x
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                                    gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                                end
                            else % ol
                                if mod(colCnt, 2)  % odd, x
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                    gasw(rowCnt, colCnt) = 1/RH; % asw
                                else % odd, xbar
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                    gasw(rowCnt, colCnt) = 1/RL; % asw
                                end
                            end
                        end
                    else % all the other cases
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = 1/RH; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RH; % asw
                        end
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            gnsw
            gbsw
            gasw
            
            % calculate vr, row voltage - deteministic
            vr = ones(1, rowNum) * VH;
            mtCnt = 1
            lutCnt = 1
            for rowCnt = 1:rowNum
                if rowStage(rowCnt) == stageCnt
                    if mtCnt < mtLut(lutCnt) + 1 % mt
                        vr(rowCnt) = VW;
                    else % ol
                        vr(rowCnt) = VG;
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1
                    else
                        mtCnt = 1
                        lutCnt = lutCnt + 1
                    end
                end
            end
            vr
            
            % calculate vc, col voltage - non-deteministic
            vcnsw = ones(1, colNum) * VH;
            vcbsw = ones(1, colNum) * VH;
            vcasw = ones(1, colNum) * VH;
            for colCnt = 1:colNum
                if sigStage(ceil(colCnt/2)) == stageCnt
                    if mod(colCnt,2) == 0 % even, xbar
                       % nsw
                       gTemp = gnsw(:,colCnt);
                       vTemp = vr;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vcnsw(colCnt) = vxTemp;
                       % bsw
                       gTemp = gbsw(:,colCnt);
                       vTemp = vr;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vcbsw(colCnt) = vxTemp;
                       % asw
                       gTemp = gasw(:,colCnt);
                       vTemp = vr;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vcasw(colCnt) = vxTemp;
                    end
                end
            end
            vcnsw
            vcbsw
            vcasw
            
            % power consumption
            % cells
            for rowCnt = 1:rowNum
                for colCnt = 1:colNum
                    if sigStage(ceil(colCnt/2)) == stageCnt
                        if mod(colCnt, 2) == 0 % (<n, =n), (=n, =n), (>n, =n)
                            Pout1 = spm(1, colCnt)
                            pDeviceNsw = (vr(rowCnt) - vcnsw(colCnt))^2 * gnsw(rowCnt, colCnt)
                            pDeviceBsw = (vr(rowCnt) - vcbsw(colCnt))^2 * gbsw(rowCnt, colCnt)
                            pDeviceAsw = (vr(rowCnt) - vcasw(colCnt))^2 * gasw(rowCnt, colCnt)
                            pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                            pGER = pGER + pDevice                           
                        else
                            pDevice = (vr(rowCnt) - vcnsw(colCnt))^2 * gnsw(rowCnt, colCnt)
                            pGER = pGER + pDevice
                        end
                    else
                        pDevice = (vr(rowCnt) - vcnsw(colCnt))^2 * gnsw(rowCnt, colCnt)
                        pGER = pGER + pDevice
                    end
                end
            end
            pGER;
            % RS
            % row
            rowGS = ones(1, rowNum) * (1/RS);
            pRSrow = vr.^2 .* rowGS;
            pRSrow = sum(pRSrow);
            pGER = pGER + pRSrow;
            % col
            colGS = ones(1, colNum) * (1/RS);
            pRScol = 0;
            for colCnt = 1:colNum
                if sigStage(ceil(colCnt/2)) == stageCnt
                    if mod(colCnt, 2) == 0 % (<n, =n), (=n, =n), (>n, =n)
                        Pout1 = spm(1, colCnt)
                        pDeviceNsw = vcnsw(colCnt)^2 * colGS(colCnt)
                        pDeviceBsw = vcbsw(colCnt)^2 * colGS(colCnt)
                        pDeviceAsw = vcasw(colCnt)^2 * colGS(colCnt)
                        pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                        pRScol = pRScol + pDevice                           
                    else
                        pDevice = vcnsw(colCnt)^2 * colGS(colCnt)
                        pRScol = pRScol + pDevice
                    end
                else
                    pDevice = vcnsw(colCnt)^2 * colGS(colCnt)
                    pRScol = pRScol + pDevice
                end
            end
            pGER = pGER + pRScol;
            
            %------------ INR --------------
            % calculate the conductance
            % nine regions divided by their stage numbers
            % denoted by (row,col)
            % (<n,<n): avg/disabled
            % (<n,=n): disabled
            % (<n,>n): disabled
            % (=n,<n): avg/diabled
            % (=n,=n): case-related/diabled
            % within (=n,=n) field, it can be further divide into four
            % subfields
            % (mt,x) - RD, (mt, xbar) - avg
            % (ol, x) - case-related: nsw - RH, bsw - RH, asw - RL
            % (ol, xbar) - case-related: nsw - RL, bsw - RH, asw - RH
            % (>n,<n),(>n,=n),(>n,>n): RH/disabled
            gnsw = ones(rowNum, colNum) * (1/RD);
            gbsw = ones(rowNum, colNum) * (1/RD);
            gasw = ones(rowNum, colNum) * (1/RD);
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum 
                for colCnt = 1:colNum
                    if (rowStage(rowCnt) < stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (<n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                            gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) < stageCnt) % (=n,<n)
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % nsw
                            gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                            gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                        end
                    elseif (rowStage(rowCnt) == stageCnt) && (sigStage(ceil(colCnt/2)) == stageCnt)% (=n,=n)
                        if xl(rowCnt, colCnt)
                            if mtCnt < mtLut(lutCnt) + 1 % mt
                                if mod(colCnt, 2)==0  % odd, x
                                    gnsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % nsw
                                    gbsw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % bsw
                                    gasw(rowCnt, colCnt) = spm(rowCnt, colCnt)/RH + (1-spm(rowCnt, colCnt))/RL; % asw
                                end
                            else % ol
                                if mod(colCnt, 2)  % odd, x
                                    gnsw(rowCnt, colCnt) = 1/RH; % nsw
                                    gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                    gasw(rowCnt, colCnt) = 1/RL; % asw
                                else % odd, xbar
                                    gnsw(rowCnt, colCnt) = 1/RL; % nsw
                                    gbsw(rowCnt, colCnt) = 1/RH; % bsw
                                    gasw(rowCnt, colCnt) = 1/RH; % asw
                                end
                            end
                        end
                    else % all the other cases
                        if xl(rowCnt, colCnt)
                            gnsw(rowCnt, colCnt) = 1/RH; % nsw
                            gbsw(rowCnt, colCnt) = 1/RH; % bsw
                            gasw(rowCnt, colCnt) = 1/RH; % asw
                        end
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            gnsw
            gbsw
            gasw
            
            % calculate vc, col voltage - deteministic
            vc = ones(1, colNum) * VH;
            for colCnt = 1:colNum
                if sigStage(ceil(colCnt/2)) == stageCnt
                    if mod(colCnt,2) % x
                        vc(colCnt) = VW;
                    end
                end
            end
            vc
            
            % calculate vr, row voltage - non-deteministic
            vrnsw = ones(1, rowNum) * VH;
            vrbsw = ones(1, rowNum) * VH;
            vrasw = ones(1, rowNum) * VH;
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum
                if rowStage(rowCnt) == stageCnt
                    if mtCnt == mtLut(lutCnt) + 1 % ol
                       % nsw
                       gTemp = gnsw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrnsw(rowCnt) = vxTemp;
                       % bsw
                       gTemp = gbsw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrbsw(rowCnt) = vxTemp;
                       % asw
                       gTemp = gasw(rowCnt,:);
                       vTemp = vc;
                       vxTemp = dot(vTemp, gTemp)/(sum(gTemp) + 1/RS);
                       vrasw(rowCnt) = vxTemp;
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1;
                    else
                        mtCnt = 1;
                        lutCnt = lutCnt + 1;
                    end
                end
            end
            vrnsw
            vrbsw
            vrasw
            
            % power consumption
            mtCnt = 1;
            lutCnt = 1;
            % cells
            for rowCnt = 1:rowNum
                for colCnt = 1:colNum
                    if rowStage(rowCnt) == stageCnt
                        if mtCnt == mtLut(lutCnt) + 1
                            Pout1 = spm(rowCnt,(lutCnt + inNum) * 2 - 1)    
                            pDeviceNsw = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                            pDeviceBsw = (vrbsw(rowCnt) - vc(colCnt))^2 * gbsw(rowCnt, colCnt)
                            pDeviceAsw = (vrasw(rowCnt) - vc(colCnt))^2 * gasw(rowCnt, colCnt)
                            pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                            pINR = pINR + pDevice    
                        else
                            pDevice = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                            pINR = pINR + pDevice
                        end
                    else
                        pDevice = (vrnsw(rowCnt) - vc(colCnt))^2 * gnsw(rowCnt, colCnt)
                        pINR = pINR + pDevice
                    end
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1
                    else
                        mtCnt = 1
                        lutCnt = lutCnt + 1
                    end
                end
            end
            pINR;
            
            % RS
            % col
            colGS = ones(1, colNum) * (1/RS);
            pRScol = vc.^2 .* colGS;
            pRScol = sum(pRScol);
            pINR = pINR + pRScol;
            % row
            rowGS = ones(1, rowNum) * (1/RS);
            pRSrow = 0;
            mtCnt = 1;
            lutCnt = 1;
            for rowCnt = 1:rowNum
                if rowStage(rowCnt) == stageCnt
                    if mtCnt == mtLut(lutCnt) + 1
                        Pout1 = spm(rowCnt,(lutCnt + inNum) * 2 - 1)    
                        pDeviceNsw = vrnsw(rowCnt)^2 * rowGS(rowCnt)
                        pDeviceBsw = vrbsw(rowCnt)^2 * rowGS(rowCnt)
                        pDeviceAsw = vrasw(rowCnt)^2 * rowGS(rowCnt)
                        pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                        pRSrow = pRSrow + pDevice    
                    else
                        pDevice = vrnsw(rowCnt)^2 * rowGS(rowCnt)
                        pRSrow = pRSrow + pDevice
                    end
                else
                    pDevice = vrnsw(rowCnt)^2 * rowGS(rowCnt)
                    pRSrow = pRSrow + pDevice
                end
                if rowCnt >= 2
                    if mtCnt < mtLut(lutCnt) + 1
                        mtCnt = mtCnt + 1
                    else
                        mtCnt = 1
                        lutCnt = lutCnt + 1
                    end
                end
            end
            pINR = pINR + pRSrow;
            
            
            
        end
        
        %------------ INA --------------
        % calcuate Vr & Vc
        vr = ones(1, rowNum) * VW;
        vc = ones(1, colNum) * VG;
        % calculate the power used to reset all the memristors
        % cells
        for rowCnt = 1:rowNum
            for colCnt = 1:colNum
                if xl(rowCnt, colCnt) % 
                    if rowCnt == 1
                        if colCnt <= 2 * inNum
                            Pout1 = spm(rowCnt,colCnt);
                            pDeviceNsw = (vr(rowCnt) - vc(colCnt))^2 / RH;
                            pDeviceBsw = (vr(rowCnt) - vc(colCnt))^2 / RL;
                            pDeviceAsw = (vr(rowCnt) - vc(colCnt))^2 / RH;
                            pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                            pINA = pINA + pDevice;
                        end
                    else
                        Pout1 = spm(rowCnt,colCnt);
                        pDeviceNsw = (vr(rowCnt) - vc(colCnt))^2 / RH;
                        pDeviceBsw = (vr(rowCnt) - vc(colCnt))^2 / RL;
                        pDeviceAsw = (vr(rowCnt) - vc(colCnt))^2 / RH;
                        pDevice = Pout1 * pDeviceNsw + (1 - Pout1) * 0.5 * (pDeviceBsw + pDeviceAsw)
                        pINA = pINA + pDevice;
                    end
                else % RD
                    pDevice = (vr(rowCnt) - vc(colCnt))^2 / RD
                    pINA = pINA + pDevice;
                end
            end
        end
        % RS
        % row
        rowGS = ones(1, rowNum) * (1/RS);
        pRSrow = vr.^2 .* rowGS;
        pRSrow = sum(pRSrow);
        pINA = pINA + pRSrow;
        % col
        colGS = ones(1, colNum) * (1/RS);
        pRScol = vc.^2 .* colGS;
        pRScol = sum(pRScol);
        pINA = pINA + pRScol;
        % power stat
        pRIN
        pCFM
        pEVM
        pGER
        pINR
        pINA
        
        %------------------ Area Estimation ------------
        % Axbar: @.st | .deviceNum*A1r
        % Avd: @.st | .memNum -> .memNum*60*F2
        % Actrl: ActrlCore + AtapBuf
        % ActrlCore = ActrlCore(stageNum)
        % @.st | .stageNum 
        % AtapBuf = (exp(1)*FO - 1)/(exp(1) - 1)*Abuf;
        % Row: mtNum @ each stage, lutNum @ each stage
        % Col: sigNum @ each stage


        Axbar = deviceNum*A1r;
        Avd = memNum*60*F2;
        Acc = ActrlCore(stageNum);
        AtapBufLB = (exp(1)*mtNum - 1)/(exp(1) - 1)*Abuf;
        AtapBufOL = (exp(1)*lutNum - 1)/(exp(1) - 1)*Abuf;
        AtapBufIMN = (exp(1)*sigNum - 1)/(exp(1) - 1)*Abuf;
        AtapBufIM = (exp(1)*sigNum - 1)/(exp(1) - 1)*Abuf;
        AtapBuf = NCTRL*(sum(AtapBufLB) + sum(AtapBufOL) + sum(AtapBufIMN) + sum(AtapBufIM));
        Acmos = Avd + Acc + AtapBuf;
        Area = max(Axbar, Acmos);
        AreaNormalized = Area/A1r;
        % K Axbar Avd Acc AtapBuf  
        AreaInfo = [K(j) Avd Acc AtapBuf Acmos Axbar Area AreaNormalized];

        %------------------ Delay Estimation ------------
        % NS: # stages @.st | .stageNum 
        % Dstep: Dxbar + Dctrl
        % Dxbar = Dnw + Tsw
        % Dnw = (n^2 + 4n - 21/8)*RCF2
        % n = max{rowNum, colNum}
        % @.st | .rowNum, .colNum

        % Dctrl = DctrlCore + DtapBuf
        % DctrlCore = DctrlCore(stageNum)
        % @.st | .stageNum 
        % DtapBuf = max{Dbuf(FO)} for each row & col
        % Dbuf(FO) = exp(1)*log(FO)*Dbuf
        % Row: mtNum @ each stage, lutNum @ each stage
        % Col: sigNum @ each stage

        n = max(rowNum, colNum);
        Dnw = (n^2 + 4*n - 21/8)*RCF2;
        Dxbar = Dnw + Tsw;
        Dcc = DctrlCore(stageNum);
        DtapBufLB = log(mtNum)*exp(1)*Dbuf;
        DtapBufOL = log(lutNum)*exp(1)*Dbuf;
        DtapBufIMN = log(sigNum)*exp(1)*Dbuf;
        DtapBufIM = log(sigNum)*exp(1)*Dbuf;
        tempDtapBuf = [max(DtapBufLB),max(DtapBufOL),max(DtapBufIMN),max(DtapBufIM)];
        DtapBuf = max(tempDtapBuf);
        Dctrl = Dcc + DtapBuf;
        Dstep = Dxbar + Dctrl;
        Delay = stageNum*Dstep;
        DelayInfo = [K(j) Dnw Tsw Dxbar Dcc DtapBuf Dstep stageNum Dstep];   
        
        
        % ---- Collect area and delay for each lut config
        
        totalAreaInfo = [totalAreaInfo ; AreaInfo];
        totalDelayInfo = [totalDelayInfo ; DelayInfo];
        
        % ---------- close files
        fclose(fidSs);
        fclose(fidMi);
        fclose(fidSt);
        fclose(fidSi);
        
        
        
        
    end % K loop; input # of luts
    % -------- Print to a file for each circuit -----------
    fprintf(fidPe,'%s\n',INPUTFILE{i});
    %AreaInfo = [K(j) Avd Acc AtapBuf Acmos Axbar Area AreaNormalized];
    fprintf(fidPe,'Area\n');
    fprintf(fidPe,'K(j)\tAvd\tAcc\tAtapBuf\tAcmos\tAxbar\tArea\tAreaNormalized\n');
    for p = 1:length(K)
        fprintf(fidPe,[repmat('%.2f\t', 1, size(totalAreaInfo(p,:), 2)) '\n'],totalAreaInfo(p,:));
    end
    fprintf(fidPe,'\n');
    % DelayInfo = [K(j) Dnw Tsw Dxbar Dcc DtapBuf Dstep stageNum Dstep];
    fprintf(fidPe,'Delay\n');
    fprintf(fidPe,'K(j)\tDnw\tTsw\tDxbar\tDcc\tDtapBuf\tDstep\tstageNum\tDstep\n');
    for p = 1:length(K)
        fprintf(fidPe,[repmat('%.4f\t', 1, size(totalDelayInfo(p,:), 2)) '\n'],totalDelayInfo(p,:));
    end
    fclose(fidPe);
end






% ------------- Log -----------
% SPEC: Map the luts on xbar and draw a mosaic graph
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 1-12-16
% 1. setup
% ------------- Extract information ------------
% sigStage: stage of each signal; .ss
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K = 3:16;
K = 3
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
%'adder'
% '4bfa'
'fa'
};

%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%-----------  Extract Signals -----------%
% inFolderPath = '.\mcnc\';
% outFolderPath = '.\layout\';
% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUTSIG = 2;  % process luts signals
PLUTTAB = 3;  % process luts table
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Exploration -----------%
%----------- Read and Print -----------%

%for i = 1:length(INPUTFILE)
%for i = length(INPUTFILE):length(INPUTFILE)
for i = 1:1
    close all
    areaInfo = [];
    rowInfo = [];
    colInfo = [];
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];
    %for j = 11:length(K)
    for j = 1:1
    %for j = 6:6
        rwlibFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.rwlib']
        ssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.ss'];  % signal stage
        suFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.su'];  % signal number
        soFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.so'];  % signal output
        miFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.mi'];  % minterm info
        xlFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.xl'];  % xbar layout
        stFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.st'];  % statistics
        mgFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.png'];  % mosaic graph
        fidRwlib = fopen(rwlibFileName);
        fidSs = fopen(ssFileName);
        fidSu = fopen(suFileName);
        fidSo = fopen(soFileName);
        fidMi = fopen(miFileName);
        fidXl = fopen(xlFileName,'w');
        fidSt = fopen(stFileName,'w');
        % Extract stage information from .si
        inNum = 0;
        outNum = 0;
        imNum = 0;
        rdCnt = 1;
        while (~feof(fidSu))
            tline = fgetl(fidSu);
            str = tline;
            if(rdCnt == 1)
                inNum = str2num(str);
            elseif(rdCnt == 2)
                outNum = str2num(str);
            elseif(rdCnt == 3)
                imNum = str2num(str);
            end
            rdCnt = rdCnt + 1;
        end
        inNum;
        outNum;
        imNum;
        % Extract minterm information from .mi
        mintermNum = [];
        while (~feof(fidMi))
            tline = fgetl(fidMi);
            str = tline;
            mintermNum = [mintermNum str2num(str)];
        end
        mintermNum;
        % Extract sigOut from .so
        sigOut = [];
        while (~feof(fidSo))
            tline = fgetl(fidSo);
            str = tline;
            sigOut = [sigOut str2num(str)];
        end
        sigOut;
        % Extract sigStage from .ss
        sigStage = [];
        while (~feof(fidSs))
            tline = fgetl(fidSs);
            str = tline;
            sigStage = [sigStage str2num(str)];
        end
        sigStage;
        % Generate the mapping matrix
        % Ini map mat
        rowNum = 1 + sum(mintermNum) + length(mintermNum);
        colNum = 2*(inNum + outNum + imNum);
        mapMat = zeros(rowNum,colNum);
        rowNum;
        colNum;
        lutNum = 0;
        % Update mapping mat
        rowCnt = 1;  % Row cnt inside the mapMat
        flagLUT = 0;
        % update IL
        mapMat(1,1:2*inNum) = ones(1,2*inNum);
        
        rowCnt = rowCnt + 1;
        % update LUTs
        while (~feof(fidRwlib))
            tline = fgetl(fidRwlib);
            str = tline;
            key = '.names';
            if(length(regexp(str,key,'match'))) % extract lut input signals
                if (flagLUT)
                    % update OL for the previous LUT
                    mapMat(rowCnt,2*lutSig(length(lutSig))-1) = 1; % OL
                    mapMat(rowCnt,2*lutSig(length(lutSig))) = 1;   % OL
                    
                    rowCnt = rowCnt + 1;
                end
                lutNum = lutNum + 1;
                flagLUT = 1;
                lutSig = [];
                key = '\w+';
                tempSig = regexp(str,key,'match');
                for p = 1:length(tempSig) 
                    lutSig = [lutSig str2num(tempSig{p})];
                end
            else % update the minterms
                rowCnt;
                str;
                lutSig;
                % update input
                for p = 1:length(lutSig)-1
                    lutSig(p);
                    2*lutSig(p)-1;
                    2*lutSig(p);
                    tempEle1 = str2num(str(2*p-1)); % x
                    tempEle2 = str2num(str(2*p));  % xbar
                    if(sigOut(lutSig(p)) == OUTON) % ON-Set
                        if(lutSig(p) <= inNum) % input 
                            mapMat(rowCnt,2*lutSig(p)-1) = tempEle1;
                            mapMat(rowCnt,2*lutSig(p)) = tempEle2;
                        else % intermediate
                            mapMat(rowCnt,2*lutSig(p)-1) = tempEle1;
                            mapMat(rowCnt,2*lutSig(p)) = tempEle2;
                        end
                    else % OFF-Set
                        mapMat(rowCnt,2*lutSig(p)-1) = tempEle1;
                        mapMat(rowCnt,2*lutSig(p)) = tempEle2;
                    end
                end
                % update output
                mapMat(rowCnt,2*lutSig(end)) = 1; % output the minterm
                mapMat(rowCnt,:);
                
                % update counter
                rowCnt = rowCnt + 1;
            end
            
        end
        % update OL for the previous LUT
        mapMat(rowCnt,2*lutSig(length(lutSig))-1) = 1; % OL
        mapMat(rowCnt,2*lutSig(length(lutSig))) = 1;   % OL
        % print mapMat
        for p = 1:rowNum
            fprintf(fidXl,[repmat('%d', 1, size(mapMat(p,:), 2)) '\n'],mapMat(p,:));
        end
        % print statistics
        fprintf(fidSt,'.inNum: %d\n',inNum); 
        fprintf(fidSt,'.outNum: %d\n',outNum); 
        fprintf(fidSt,'.imNum: %d\n',imNum); 
        fprintf(fidSt,'.lutNum: %d\n',lutNum); 
        fprintf(fidSt,'.rowNum: %d\n',rowNum); 
        fprintf(fidSt,'.colNum: %d\n',colNum); 
        fprintf(fidSt,'.deviceNum: %d\n',rowNum*colNum); 
        fprintf(fidSt,'.stageNum: %d\n',max(sigStage)); 
        fprintf(fidSt,'.memNum: %d\n',sum(sum(mapMat))); 
        % plot mosaic graph
        figure
        colormap('hot');   % set colormap
        imagesc(1-mapMat);        % draw image and scale colormap to values range
        % imagesc(ACSST);        % draw image and scale colormap to values range
        colorbar;          % show color scale
        saveas(gcf,mgFileName);
        % collect xbar area
        areaInfo = [areaInfo rowNum*colNum];
        % collect xbar row
        rowInfo = [rowInfo rowNum];
        % collect xbar area
        colInfo = [colInfo colNum];
        fclose(fidRwlib);
        fclose(fidSs);
        fclose(fidSu);
        fclose(fidSo);
        fclose(fidMi);
        fclose(fidXl);
        fclose(fidSt);
    end
    figure
    plot(K,areaInfo)
    areaFileName = [outFolderPath,INPUTFILE{i},'_area.png'];  % mosaic graph
    saveas(gcf,areaFileName);
    figure
    plot(K,rowInfo)
    rowFileName = [outFolderPath,INPUTFILE{i},'_row.png'];  % mosaic graph
    saveas(gcf,rowFileName);
    figure
    plot(K,colInfo)
    colFileName = [outFolderPath,INPUTFILE{i},'_col.png'];  % mosaic graph
    saveas(gcf,colFileName);
end

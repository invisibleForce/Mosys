%------------- Log -----------
% SPEC: Estimate the performance of the design
% Author: Lei
% Function list:
% Date: 19.05.20
% verify the gates 
%------------- Log -----------
clc
clear all
close all

%-----------  Parameters -----------% 
% General
kilo = 1e3      %unit
micro = 1e-6    % micro
% Technology
F = 90e-3; % Tech node, 90nm, unit um
F2 = F*F; % area of F^2,  , unit um^2
Tsw = 0.2;             % Switching time of a memristor, ns
RCF2 = 2.06e-17/1e-9;  % Unit delay, ns
RL = 200 * kilo             % Low resistance 200kOhm
rHL = 7  * kilo             % RH/RL
rDH = 50                    % RD/RH
rSL = 10                    % RS/RL
RH = rHL * RL               % High resistance
RD = rDH * RH               % Disabled resistance
RS = rSL * RL               % Reference resistor
% control voltage
VW = 2.1                    % write voltage
VH = 1.05                   % half-select voltage
VG = 0                      % ground voltage

%---------------------
% copy
%---------------------
% gate config
nIn = 1;    % number of inputs
nOut = 1;   % number of outputs
% baseline
power = [];
for inLogic = 0:1
    % logic values
    outLogic = inLogic; % copy
    
    % voltage given
    vr = ones(1, nIn + nOut) * VG; 
    vr(1) = VW;
    
    gnsw = ones(1, nIn + nOut) * 1/RH; 
    gbsw = ones(1, nIn + nOut) * 1/RH; 
    gasw = ones(1, nIn + nOut) * 1/RH; 
    if inLogic == 0 % BSW/ASW
        % BSW
        % conductance
        gbsw(1) = 1/RL;
        % voltage vx
        vxbsw = sum(vr .* gbsw);
        vxbsw = vxbsw /(sum(gbsw) + 1/RS);
        % power
        % cells
        pDevice = (vr - vxbsw).^2 .* gbsw;
        pGateBSW = sum(pDevice);
        % RS
        pGateBSW = pGateBSW + vxbsw^2 / RS;
        pGateBSW = pGateBSW / micro; % in uW
        
        % ASW
        gasw = ones(1, nIn + nOut) * 1/RL; 
        % voltage vx
        vxasw = sum(vr .* gasw);
        vxasw = vxasw /(sum(gasw) + 1/RS);
        % power
        % cells
        pDevice = (vr - vxasw).^2 .* gasw;
        pGateASW = sum(pDevice);
        % RS
        pGateASW = pGateASW + vxasw^2 / RS;
        pGateASW = pGateASW / micro; % in uW
        % power consumed by a gate
        pGate = 0.5 * (pGateASW + pGateBSW);
        power = [power pGate];
    else % inLogic = 1, RH
        % NSW
        % voltage vx
        vxnsw = sum(vr .* gnsw);
        vxnsw = vxnsw /(sum(gnsw) + 1/RS);
        % power
        % cells
        pDevice = (vr - vxnsw).^2 .* gnsw;
        pGateNSW = sum(pDevice);
        % RS
        pGateNSW = pGateNSW + vxnsw^2 / RS ;
        pGateNSW = pGateNSW / micro;
        % power consumed by a gate
        pGate = pGateNSW;
        power = [power pGate];
    end
end
pGateNSW
pGateBSW
pGateASW
powerBaseline = power % unit: uW
powerAvg = sum(powerBaseline)/length(powerBaseline)
% probability
% gate config
power = [];


% voltage given
vr = ones(1, nIn + nOut) * VG; 
vr(1) = VW;

gnsw = ones(1, nIn + nOut) * 1/RH; 
gbsw = ones(1, nIn + nOut) * 1/RH; 
gasw = ones(1, nIn + nOut) * 1/RH; 
inLogic = 0; % BSW/ASW
P1 = 0.5; % probability when the output is 1
P0 = 1 - P1;

% BSW
% conductance
gbsw(1) = 1/RL;
% voltage vx
vxbsw = sum(vr .* gbsw);
vxbsw = vxbsw /(sum(gbsw) + 1/RS);
% power
% cells
pDevice = (vr - vxbsw).^2 .* gbsw;
pGateBSW = sum(pDevice);
% RS
pGateBSW = pGateBSW + vxbsw^2 / RS;
pGateBSW = pGateBSW / micro;

% ASW
gasw = ones(1, nIn + nOut) * 1/RL; 
% voltage vx
vxasw = sum(vr .* gasw);
vxasw = vxasw /(sum(gasw) + 1/RS);
% power
% cells
pDevice = (vr - vxasw).^2 .* gasw;
pGateASW = sum(pDevice);
% RS
pGateASW = pGateASW + vxasw^2 / RS;
pGateASW = pGateASW / micro;
% power consumed by a gate
pGate = 0.5 * (pGateASW + pGateBSW);
power = [power pGate];

% NSW
% voltage vx
vxnsw = sum(vr .* gnsw);
vxnsw = vxnsw /(sum(gnsw) + 1/RS);
% power
% cells
pDevice = (vr - vxnsw).^2 .* gnsw;
pGateNSW = sum(pDevice);
% RS
pGateNSW = pGateNSW + vxnsw^2 / RS;
pGateNSW = pGateNSW / micro;
% power consumed by a gate
pGate = pGateNSW;
power = [power pGate];
pGateNSW
pGateBSW
pGateASW
powerProb = power % unit: uW
powerAvg = powerProb(1) * P0 + powerProb(2) * P1



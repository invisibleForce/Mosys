% ------------- Log -----------
% SPEC: order the signals using its stage number asendingly
% Author: Lei
% Function list:
% Coefficient: 
% Voltages: 
% Date: 2019.5.7
% 1. reorder the signals
% output a two-column array
% sigOrder and its sigStage
% The index of this array is the signal name of the previous sigName
% ------------- Extract information ------------
% sigStage: stage of each signal; .ss
% ------------- Log -----------
clc
clear all
close all

% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation
%N = [1 2 4 6 8 10 12 16]; % Cluster size

%-----------  Design Information -----------%
% Configuration of LUTs
% K = 3:16;
K = 3
%K = [4 8 12];
% Input blif file list
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% epfl benchmark
INPUTFILE = {
%'adder'
% '4bfa'
'fa'
};

%----------- Variable -------------------%
% nIn : Input Signal Number
% nOut : Output Signal Number
% seg: the line will continue or not

%-----------  Extract Signals -----------%
% inFolderPath = '.\mcnc\';
% outFolderPath = '.\layout\';
% Continue line
CLY = 1; % continue, check \
CLN = 0; % one line only
% Find the target
HIT = 1; % hit the target to find
MISS = 0; % missing
% Phase 
PIN = 0;   % process input signals
POUT = 1;  % process output signals
PLUTSIG = 2;  % process luts signals
PLUTTAB = 3;  % process luts table
% Signal Ouput Types
OUTON = 0;    % ON-Set, 1/n minterms
OUTOFF1 = 1;  % OFF-Set, 1 minterm
OUTOFFN = 2;  % OFF-Set, n minterms
%----------- Exploration -----------%
%----------- Read and Print -----------%

%for i = 1:length(INPUTFILE)
%for i = length(INPUTFILE):length(INPUTFILE)
for i = 1:1
    close all
    areaInfo = [];
    rowInfo = [];
    colInfo = [];
    inFolderPath = ['.\',INPUTFILE{i},'\'];
    outFolderPath = ['.\',INPUTFILE{i},'\'];
    %for j = 11:length(K)
    for j = 1:1
    %for j = 6:6
        ssFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.ss'];  % signal stage
        sodFileName = [outFolderPath,INPUTFILE{i},'_lut',num2str(K(j)),'.sod'];  % signal order
        fidSs = fopen(ssFileName);
        fidSod = fopen(sodFileName,'w');
        % Extract sigStage from .ss
        sigStage = [];
        while (~feof(fidSs))
            tline = fgetl(fidSs);
            str = tline;
            sigStage = [sigStage str2num(str)];
        end
        stageNum = max(sigStage)
        % order the signals using the singal stage and signal 
        sigOrder = zeros(length(sigStage), 2);
        sigIdx = 1;
        for stageCnt = 0:stageNum
            for sigCnt = 1:length(sigStage)
                if sigStage(sigCnt) == stageCnt
                    sigOrder(sigIdx, 1) = sigCnt; % write the signalName
                    sigOrder(sigIdx, 2) = stageCnt; % write its stageNum
                    sigIdx = sigIdx + 1;
                end
            end
        end
        % switch the singal order and signal name
        sigList = zeros(length(sigStage), 2);
        for sigCnt = 1:length(sigStage)
            sigList(sigOrder(sigCnt),1) = sigCnt
            sigList(sigOrder(sigCnt),2) = sigOrder(sigCnt, 2)
        end
        sigOrder
        sigList
        % print the signal stages
        for p = 1:length(sigStage)
            fprintf(fidSod,'%d %d\n',sigList(p, 1), sigList(p, 2));
        end
        fclose(fidSs);
        fclose(fidSod);
    end   
end

%------------- Log -----------
% SPEC: Estimate the performance of and gate
% Author: Lei
% Function list:
% Date: 19.05.20
% verify AND gates 
%------------- Log -----------
clc
clear all
close all

%-----------  Parameters -----------% 
% General
kilo = 1e3      %unit
micro = 1e-6    % micro
% Technology
F = 90e-3; % Tech node, 90nm, unit um
F2 = F*F; % area of F^2,  , unit um^2
Tsw = 0.2;             % Switching time of a memristor, ns
RCF2 = 2.06e-17/1e-9;  % Unit delay, ns
RL = 200 * kilo             % Low resistance 200kOhm
rHL = 7  * kilo             % RH/RL
rDH = 50                    % RD/RH
rSL = 10                    % RS/RL
RH = rHL * RL               % High resistance
RD = rDH * RH               % Disabled resistance
RS = rSL * RL               % Reference resistor
% control voltage
VW = 2.1                    % write voltage
VH = 1.05                   % half-select voltage
VG = 0                      % ground voltage

%---------------------
% and
%---------------------

% gate config
nIn = 10;    % number of inputs
nOut = 1;   % number of outputs
% --------------------
% baseline, exhaustive searching
% --------------------
power = [];
inNum = 2^nIn;
pGateBSW = zeros(1,inNum-1);
pGateASW = zeros(1,inNum-1);
pGateNSW = zeros(1,inNum-1);
for inLogic = 0:inNum-1
    % generate binary inputs
    inValue = dec2bin(inLogic, nIn)
    % voltage given
    v = ones(1, nIn + nOut) * VW; 
    v(end) = VG;
    
    gnsw = ones(1, nIn + nOut) * 1/RH; 
    gbsw = ones(1, nIn + nOut) * 1/RH; 
    gasw = ones(1, nIn + nOut) * 1/RH; 
    if inLogic ~= inNum-1 % BSW/ASW
        % BSW
        % conductance
        for tempCnt = 1:nIn
            if str2num(inValue(tempCnt)) == 0
                gbsw(tempCnt) = 1/RL;
            end
        end
        % voltage vx
        vxbsw = sum(v .* gbsw);
        vxbsw = vxbsw /(sum(gbsw) + 1/RS);
        % power
        % cells
        pDevice = (v - vxbsw).^2 .* gbsw;
        pGateBSW(inLogic+1) = sum(pDevice);
        % RS
        pGateBSW(inLogic+1) = pGateBSW(inLogic+1) + vxbsw^2 / RS;
        pGateBSW(inLogic+1) = pGateBSW(inLogic+1) / micro; % in uW
        
        % ASW
        for tempCnt = 1:nIn
            if str2num(inValue(tempCnt)) == 0
                gasw(tempCnt) = 1/RL;
            end
        end
        gasw(end) = 1/RL; 
        % voltage vx
        vxasw = sum(v .* gasw);
        vxasw = vxasw /(sum(gasw) + 1/RS);
        % power
        % cells
        pDevice = (v - vxasw).^2 .* gasw;
        pGateASW(inLogic+1) = sum(pDevice);
        % RS
        pGateASW(inLogic+1) = pGateASW(inLogic+1) + vxasw^2 / RS;
        pGateASW(inLogic+1) = pGateASW(inLogic+1) / micro; % in uW
        % power consumed by a gate
        pGate = 0.5 * (pGateASW(inLogic+1) + pGateBSW(inLogic+1));
        power = [power pGate];
    else % inLogic == 2^n - 1, RH
        % NSW
        % voltage vx
        vxnsw = sum(v .* gnsw);
        vxnsw = vxnsw /(sum(gnsw) + 1/RS);
        % power
        % cells
        pDevice = (v - vxnsw).^2 .* gnsw;
        pGateNSW = sum(pDevice);
        % RS
        pGateNSW = pGateNSW + vxnsw^2 / RS ;
        pGateNSW = pGateNSW / micro;
        % power consumed by a gate
        pGate = pGateNSW;
        power = [power pGate];
    end
end
pGateNSW
pGateBSW
pGateASW
powerBaseline = power % unit: uW
powerAvg = sum(powerBaseline)/length(powerBaseline)
% probability
% gate config
power = [];

% --------------------
% Probability
% --------------------
% voltage given
v = ones(1, nIn + nOut) * VW; 
v(end) = VG;

gnsw = ones(1, nIn + nOut) * 1/RH; 
gbsw = ones(1, nIn + nOut) * 1/RH; 
gasw = ones(1, nIn + nOut) * 1/RH; 
P1 = 0.5; % probability when the output is 1
P0 = 1 - P1;

% BSW
% conductance
gAvg = P1 / RH + P0 / RL;
gbsw(1:end-1) = gAvg;
% voltage vx
vxbsw = sum(v .* gbsw);
vxbsw = vxbsw /(sum(gbsw) + 1/RS);
% power
% cells
pDevice = (v - vxbsw).^2 .* gbsw;
pGateBSW = sum(pDevice);
% RS
pGateBSW = pGateBSW + vxbsw^2 / RS;
pGateBSW = pGateBSW / micro;

% ASW
gasw = gbsw; 
gasw(end) = 1 / RL; 
% voltage vx
vxasw = sum(v .* gasw);
vxasw = vxasw /(sum(gasw) + 1/RS);
% power
% cells
pDevice = (v - vxasw).^2 .* gasw;
pGateASW = sum(pDevice);
% RS
pGateASW = pGateASW + vxasw^2 / RS;
pGateASW = pGateASW / micro;
% power consumed by a gate
pGate = 0.5 * (pGateASW + pGateBSW);
power = [power pGate];

% NSW
% voltage vx
vxnsw = sum(v .* gnsw);
vxnsw = vxnsw /(sum(gnsw) + 1/RS);
% power
% cells
pDevice = (v - vxnsw).^2 .* gnsw;
pGateNSW = sum(pDevice);
% RS
pGateNSW = pGateNSW + vxnsw^2 / RS;
pGateNSW = pGateNSW / micro;
% power consumed by a gate
pGate = pGateNSW;
power = [power pGate];
pGateNSW
pGateBSW
pGateASW
powerProb = power % unit: uW
P1Gate = P1^nIn
P0Gate = 1 - P1Gate
powerAvg = powerProb(1) * P0Gate + powerProb(2) * P1Gate



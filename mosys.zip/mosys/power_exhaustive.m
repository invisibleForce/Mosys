%------------- Log -----------
% SPEC: Estimate power consumption using the exhaustive searching
% Author: Lei
% Function list:
% Date: 2019.05.20
%------------- Log -----------
clc
clear all
close all
tic % start a timer
% Example
%./t-vpack ./lut_result/alu4_lut4.blif alu4_lut10_N16.net -lut_size 4 -cluster_size 16 -inputs_per_cluster 22
% K <=7, But I try to change it in tvpack
% N has no limitation

%-----------  Script parameters -----------%


%-----------  Design Information -----------%
% INPUTFILE = {
% 'alu4';
% 'apex2';
% 'apex4';
% 'ex5p';
% 'pdc';
% 'seq';
% 'spla';
% 'des';
% 'misex3'
% };

% INPUTFILE = {
% 'add8'; 
% 'add16';
% 'add32';
% 'mul8'; 
% 'mul16';
% 'mul32'
% };

% K = 3:16;
K = 3

% epfl benchmark
INPUTFILE = {
% 'adder'
'4bfa'
};

 

%-----------  Parameters -----------% 
% General
kilo = 1e3      %unit
micro = 1e-6    % micro
% Technology
F = 90e-3; % Tech node, 90nm, unit um
F2 = F*F; % area of F^2,  , unit um^2
Tsw = 0.2;             % Switching time of a memristor, ns
RCF2 = 2.06e-17/1e-9;  % Unit delay, ns
RL = 200 * kilo             % Low resistance 200kOhm
rHL = 7  * kilo             % RH/RL
rDH = 50                    % RD/RH
rSL = 10                    % RS/RL
RH = rHL * RL               % High resistance
RD = rDH * RH               % Disabled resistance
RS = rSL * RL               % Reference resistor
% control voltage
VW = 2.1                    % write voltage
VH = 1.05                   % half-select voltage
VG = 0                      % ground voltage

% circuit config -- fa
% inNum = 3;
% nPossibleInput = 2^inNum;

% xbar layout - fa
% xl = [
% 1.00 	1.00 	1.00 	1.00 	1.00 	1.00 	0.00 	0.00 	0.00 	0.00;
% 1.00 	0.00 	0.00 	1.00 	0.00 	1.00 	0.00 	1.00 	0.00 	0.00; 
% 0.00 	1.00 	1.00 	0.00 	0.00 	1.00 	0.00 	1.00 	0.00 	0.00;
% 0.00 	1.00 	0.00 	1.00 	1.00 	0.00 	0.00 	1.00 	0.00 	0.00; 
% 1.00 	0.00 	1.00 	0.00 	1.00 	0.00 	0.00 	1.00 	0.00 	0.00; 
% 0.00 	0.00 	0.00 	0.00 	0.00 	0.00 	1.00 	1.00 	0.00 	0.00; 
% 0.00 	1.00 	1.00 	0.00 	1.00 	0.00 	0.00 	0.00 	0.00 	1.00; 
% 1.00 	0.00 	0.00 	1.00 	1.00 	0.00 	0.00 	0.00 	0.00 	1.00; 
% 1.00 	0.00 	1.00 	0.00 	0.00 	1.00 	0.00 	0.00 	0.00 	1.00; 
% 1.00 	0.00 	1.00 	0.00 	1.00 	0.00 	0.00 	0.00 	0.00 	1.00; 
% 0.00 	0.00 	0.00 	0.00 	0.00 	0.00 	0.00 	0.00 	1.00 	1.00  
% ]
% [rowNum colNum] = size(xl)


% --------------- Input files -----------
inFolderPath = ['.\',INPUTFILE{1},'\'];
outFolderPath = ['.\',INPUTFILE{1},'\'];  
ssFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.rwss'];  % signal stage, rewritten
miFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.rwmi'];  % minterm # of each lut, rewritten
stFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.st'];  % statistics
siFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.si'];  % signal list of each lut
xlFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.xl'];  % xbar layout
spmFileName = [outFolderPath,INPUTFILE{1},'_lut',num2str(K(1)),'.spm'];  % signal probability matrix
fidSs = fopen(ssFileName);
fidMi = fopen(miFileName);
fidSt = fopen(stFileName);
fidSi = fopen(siFileName);
fidXl = fopen(xlFileName);
fidSpm = fopen(spmFileName);


% ---------------- Parameter extraction ------------
% Xbar

% @.st
% inNum
% outNum
% imNum        
% deviceNum
% memNum
% stageNum
% rowNum
% colNum
while (~feof(fidSt))
    tline = fgetl(fidSt);
    str = tline;
    % inNum
    key = '.inNum';
    if(length(regexp(str,key,'match'))) % extract inNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        inNum = str2num(tempStr{1}); 
    end
    % outNum
    key = '.outNum';
    if(length(regexp(str,key,'match'))) % extract outNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        outNum = str2num(tempStr{1}); 
    end
    % imNum
    key = '.imNum';
    if(length(regexp(str,key,'match'))) % extract imNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        imNum = str2num(tempStr{1}); 
    end
    % deviceNum
    key = '.deviceNum';
    if(length(regexp(str,key,'match'))) % extract deviceNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        deviceNum = str2num(tempStr{1}); 
    end
    % memNum
    key = '.memNum';
    if(length(regexp(str,key,'match'))) % extract memNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        memNum = str2num(tempStr{1}); 
    end
    % stageNum
    key = '.stageNum';
    if(length(regexp(str,key,'match'))) % extract stageNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        stageNum = str2num(tempStr{1}); 
    end
    % rowNum
    key = '.rowNum';
    if(length(regexp(str,key,'match'))) % extract rowNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        rowNum = str2num(tempStr{1}); 
    end
    % colNum
    key = '.colNum';
    if(length(regexp(str,key,'match'))) % extract colNum
        key = '\d+';
        tempStr = regexp(str,key,'match');
        colNum = str2num(tempStr{1});
    end
end

% --- Read in signal stage ------------
sigStage = [];
while (~feof(fidSs))
    tline = fgetl(fidSs);
    str = tline;
    sigStage = [sigStage str2num(str)];
end
length(sigStage);
% ----- Extract signal number in each stage -----    
sigNum = zeros(1,stageNum + 1);
for p = 1:length(sigStage)
    sigNum(sigStage(p)+1) = sigNum(sigStage(p)+1) + 1;  % due to the stage starts from 0 to stageNum - 1
end
sigNum;
% --- Read in minterm per lut ------------
mtLut = [];
while (~feof(fidMi))
    tline = fgetl(fidMi);
    str = tline;
    mtLut = [mtLut str2num(str)];
end
length(mtLut);
% ----- Extract stage for each lut -----
lutStage = sigStage(inNum + 1:end);
% ----- Calculate row stage -----
rowStage = [];
% primary input row
rowStage = [rowStage 0];
% other rows
for lutCnt = 1:length(lutStage)
    for mtCnt = 1:(mtLut(lutCnt) + 1)
        rowStage = [rowStage lutStage(lutCnt)];
    end
end
rowStage
size(rowStage)

% ----- Extract minterm number in each stage -----    
mtNum = zeros(1,stageNum);
for p = 1:length(lutStage)
    mtNum(lutStage(p)) = mtNum(lutStage(p)) + mtLut(p);  % due to the stage starts from 0 to stageNum - 1
end
lutStage
% ----- Extract lut number in each stage ----- 
lutNum = zeros(1,stageNum);
for p = 1:length(lutStage)
    lutNum(lutStage(p)) = lutNum(lutStage(p)) + 1;  % due to the stage starts from 0 to stageNum - 1
end
length(lutNum);

%--------------------------
% Read xl into a matrix
%--------------------------
xl = [];
while (~feof(fidXl))
    tline = fgetl(fidXl);
    str = tline;
    % extract numbers
    key = '\d';
    word = regexp(str,key,'match');
    xlLine = []; 
    for k = 1:length(word)
        xlLine = [xlLine, str2num(word{k})];
    end
%             xlLine
    xl = [xl; xlLine];
end
xl
%         [xlRowNum xlColNum] = size(xl)
        
%------------------ Power Estimation ------------

% power
pRINAvg = 0;
pCFMAvg = 0;
pEVMAvg = 0;
pGERAvg = 0;
pINRAvg = 0;
pINAAvg = 0;
nPossibleInput = 2^inNum;
for input = 0 : nPossibleInput - 1
    pRIN = 0;
    pCFM = 0;
    pEVM = 0;
    pGER = 0;
    pINR = 0;
    pINA = 0;
    % ini the resistance map
    gMap = ones(rowNum, colNum) / RD;
    dMap = zeros(rowNum, colNum);
    for rowCnt = 1 : rowNum
        for colCnt = 1 : colNum
            if xl(rowCnt, colCnt)
                gMap(rowCnt, colCnt) = 1 / RH;
            end
        end
    end
    gMap
    % input value
    inValue = dec2bin(input, inNum)
    %---------- RIN -----------
    % obtain gMapStart and gMapEnd
    % set the IL based on the input value
    gMapStart = gMap;
    gMapEnd = gMapStart;
    dMapStart = dMap;
    dMapEnd = dMapStart; % data map
    for tempCnt = 1 : inNum
        if str2num(inValue(tempCnt)) == 0
            gMapEnd(1, 2 * (tempCnt - 1) + 1) = 1/RL;
        else
            gMapEnd(1, 2 * tempCnt) = 1/RL;
        end
    end
    gMapStart
    gMapEnd
    for tempCnt = 1 : inNum
        if str2num(inValue(tempCnt)) == 0
            dMapEnd(1, 2 * tempCnt) = 1;
        else
            dMapEnd(1, 2 * (tempCnt - 1) + 1) = 1;
        end
    end
    dMapStart
    dMapEnd
    % vr
    vrStart = ones(1, rowNum) * VH;
    vrStart(1) = VG;
    vrEnd = vrStart
    % vc
    vcStart = ones(1, rowNum) * VH;
    for tempCnt = 1 : inNum
        if str2num(inValue(tempCnt)) == 0
            vcStart(2 * (tempCnt - 1) + 1) = VW;
            vcStart(2 * tempCnt) = VG;
        else
            vcStart(2 * (tempCnt - 1) + 1) = VG;
            vcStart(2 * tempCnt) = VW;
        end
    end
    vcEnd = vcStart
    % power
    % cells
    for rowCnt = 1 : rowNum
        for colCnt = 1 : colNum
            pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
            pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pRIN = pRIN + pDevice;
        end
    end
    pRINCell = pRIN
    pRIN
    % RS
    % row
    for rowCnt = 1 : rowNum
        pDeviceStart = vrStart(rowCnt)^2 / RS;
        pDeviceEnd = vrEnd(rowCnt)^2 / RS;
        pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
        pRIN = pRIN + pDevice;
    end
    pRINRSRow = pRIN - pRINCell;
    % col
    for colCnt = 1 : colNum
        pDeviceStart = vcStart(colCnt)^2 / RS;
        pDeviceEnd = vcEnd(colCnt)^2 / RS;
        pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
        pRIN = pRIN + pDevice;
    end
    pRINRSCol = pRIN - pRINCell - pRINRSRow;
    pRINCell
    pRINRSRow
    pRINRSCol
    pRIN
    
    % stage loop
    for stageCnt = 1:stageNum
        %---------- CFM -----------
        % obtain gMapStart and gMapEnd
        % set the IL based on the input value
        gMapStart = gMapEnd;
        for colCnt = 1 : colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt - 1) % signals need to update
                if stageCnt == 1 % inputs are IL
                    if gMapStart(1, colCnt) == 1/RL
                        for rowCnt = 2 : rowNum
                            if xl(rowCnt, colCnt)
                                gMapEnd(rowCnt, colCnt) = 1/RL;
                            end
                        end
                    end
                else % inputs are ol of each stageCnt - 1
                    mtCnt = 1;
                    lutCnt = 1;
                    gUpdateFlag = 0;
                    for rowCnt = 2 : rowNum
                        if rowStage(rowCnt) == stageCnt - 1
                           if  mtCnt == mtLut(lutCnt) + 1 % ol
                               if gMapStart(rowCnt, colCnt) == 1/RL
                                   gUpdateFlag = 1;
                               end
                           end
                        end
                        if gUpdateFlag && xl(rowCnt, colCnt)
                            gMapEnd(rowCnt, colCnt) = 1/RL;
                        end
                        if rowCnt >= 2
                            if mtCnt < mtLut(lutCnt) + 1
                                mtCnt = mtCnt + 1;
                            else
                                mtCnt = 1;
                                lutCnt = lutCnt + 1;
                            end
                        end
                    end
                end
            end
        end
        gMapStart
        gMapEnd
        % data Map updating
        dMapStart = dMapEnd;
        for colCnt = 1 : colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt - 1) % signals need to update
                if stageCnt == 1 % inputs are IL
                    if dMapStart(1, colCnt) == 1
                        for rowCnt = 2 : rowNum
                            if xl(rowCnt, colCnt)
                                dMapEnd(rowCnt, colCnt) = 1;
                            end
                        end
                    end
                else % inputs are ol of each stageCnt - 1
                    mtCnt = 1;
                    lutCnt = 1;
                    dUpdateFlag = 0;
                    for rowCnt = 2 : rowNum
                        if rowStage(rowCnt) == stageCnt - 1
                           if  mtCnt == mtLut(lutCnt) + 1 % ol
                               if dMapStart(rowCnt, colCnt) == 1
                                   dUpdateFlag = 1;
                               end
                           end
                        end
                        if dUpdateFlag && xl(rowCnt, colCnt)
                            dMapEnd(rowCnt, colCnt) = 1;
                        end
                        if rowCnt >= 2
                            if mtCnt < mtLut(lutCnt) + 1
                                mtCnt = mtCnt + 1;
                            else
                                mtCnt = 1;
                                lutCnt = lutCnt + 1;
                            end
                        end
                    end
                end
            end
        end
        
        dMapStart
        dMapEnd
        % vr
        vrStart = ones(1, rowNum) * VH;
        for rowCnt = 1 : rowNum
            if rowStage(rowCnt) == stageCnt - 1
                vrStart(rowCnt) = VW;
            elseif rowStage(rowCnt) > stageCnt - 1
                vrStart(rowCnt) = VG;
            end
        end
        vrEnd = vrStart
        % vc
        vcStart = ones(1, rowNum) * VH;
        % vx, stageCnt - 1
        for colCnt = 1 : colNum
           if (sigStage(ceil(colCnt/2)) == stageCnt - 1)
                vcStart(colCnt) = vrStart * gMapStart(:, colCnt);
                vcStart(colCnt) = vcStart(colCnt) / (sum(gMapStart(:, colCnt)) + 1 / RS);
           end
        end
        % v
        vcEnd = ones(1, rowNum) * VH;
        % vx, stageCnt - 1
        for colCnt = 1 : colNum
           if (sigStage(ceil(colCnt/2)) == stageCnt - 1)
                vcEnd(colCnt) = vrEnd * gMapEnd(:, colCnt);
                vcEnd(colCnt) = vcEnd(colCnt) / (sum(gMapEnd(:, colCnt)) + 1 / RS);
           end
        end
        vcStart
        vcEnd
        % power
        for rowCnt = 1 : rowNum
            for colCnt = 1 : colNum
                pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
                pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
                pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
                pCFM = pCFM + pDevice;
            end
        end
        pCFMCell = pCFM;
        % RS
        % row
        for rowCnt = 1 : rowNum
            pDeviceStart = vrStart(rowCnt)^2 / RS;
            pDeviceEnd = vrEnd(rowCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pCFM = pCFM + pDevice;
        end
        pCFMRSRow = pCFM - pCFMCell;
        % col
        for colCnt = 1 : colNum
            pDeviceStart = vcStart(colCnt)^2 / RS;
            pDeviceEnd = vcEnd(colCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pCFM = pCFM + pDevice;
        end
        pCFMRSCol = pCFM - pCFMCell - pCFMRSRow;
        pCFMCell
        pCFMRSRow
        pCFMRSCol
        pCFM

        %---------- EVM -----------
        % obtain gMapStart and gMapEnd
        % set the IL based on the input value
        % update data Map 
        dMapStart = dMapEnd;
        mtCnt = 1;
        lutCnt = 1;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 0) && (xl(rowCnt, colCnt))
                        if (sum(dMapStart(rowCnt, 1 : colCnt - 1)) < sum(xl(rowCnt, 1 : colCnt - 1)))
                            if mtCnt < mtLut(lutCnt) + 1 
                                dMapEnd(rowCnt, colCnt) = 1;
                            end
                        end   
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        dMapStart
        dMapEnd

        % update conductance map
        mtCnt = 1;
        lutCnt = 1;
        gMapStart = gMapEnd;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 0) && (xl(rowCnt, colCnt))
                        if (sum(dMapStart(rowCnt, 1 : colCnt - 1)) == sum(xl(rowCnt, 1 : colCnt - 1))) && (mtCnt < mtLut(lutCnt) + 1)
                            gMapEnd(rowCnt, colCnt) = 1/RL;
                        end   
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        gMapStart
        gMapEnd
        % vc
        vcStart = ones(1, colNum) * VH;
        for colCnt = 1:colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt)
                vcStart(colCnt) = VW;
            end
        end
        vcEnd = vcStart;
        vcStart
        vcEnd
        % vr
        vrStart = ones(1, rowNum) * VH;
        % vx, bsw
        mtCnt = 1;
        lutCnt = 1;
        for rowCnt = 2 : rowNum
            if (rowStage(rowCnt) == stageCnt) && (mtCnt < mtLut(lutCnt) + 1)
                vrStart(rowCnt) = vcStart * gMapStart(rowCnt, :)';
                vrStart(rowCnt) = vrStart(rowCnt) / (sum(gMapStart(rowCnt, :)) + 1 / RS);
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        vrStart
        % vx, asw
        vrEnd = ones(1, rowNum) * VH;
        mtCnt = 1;
        lutCnt = 1;
        for rowCnt = 2 : rowNum
            if (rowStage(rowCnt) == stageCnt) && (mtCnt < mtLut(lutCnt) + 1)
                vrEnd(rowCnt) = vcEnd * gMapEnd(rowCnt, :)';
                vrEnd(rowCnt) = vrEnd(rowCnt) / (sum(gMapEnd(rowCnt, :)) + 1 / RS);
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        vrEnd
        % power
        for rowCnt = 1 : rowNum
            for colCnt = 1 : colNum
                pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
                pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
                pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
                pEVM = pEVM + pDevice;
            end
        end
        pEVMCell = pEVM;
        % RS
        % row
        for rowCnt = 1 : rowNum
            pDeviceStart = vrStart(rowCnt)^2 / RS;
            pDeviceEnd = vrEnd(rowCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pEVM = pEVM + pDevice;
        end
        pEVMRSRow = pEVM - pEVMCell;
        % col
        for colCnt = 1 : colNum
            pDeviceStart = vcStart(colCnt)^2 / RS;
            pDeviceEnd = vcEnd(colCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pEVM = pEVM + pDevice;
        end
        pEVMRSCol = pEVM - pEVMCell - pEVMRSRow;
        pEVMCell
        pEVMRSRow
        pEVMRSCol
        pEVM

        %---------- GER -----------
        % update data map for start and end
        % obtain gMapStart and gMapEnd
        % set the IL based on the input value
        % update data Map 
        mtCnt = 1;
        lutCnt = 1;
        dMapStart = dMapEnd;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 0) && (xl(rowCnt, colCnt))
                        if (sum(dMapStart(1 : rowCnt - 1, colCnt)) == sum(xl(1 : rowCnt - 1, colCnt)))
                            if mtCnt == mtLut(lutCnt) + 1 
                                dMapEnd(rowCnt, colCnt) = 1;
                            end
                        end   
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        dMapStart
        dMapEnd

        % update conductance map
        mtCnt = 1;
        lutCnt = 1;
        gMapStart = gMapEnd;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 0) && (xl(rowCnt, colCnt))
                        if (sum(dMapStart(1 : rowCnt - 1, colCnt)) < sum(xl(1 : rowCnt - 1, colCnt)))
                            if mtCnt == mtLut(lutCnt) + 1 
                                gMapEnd(rowCnt, colCnt) = 1/RL;
                            end
                        end 
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        gMapStart
        gMapEnd
        % vr
        vrStart = ones(1, rowNum) * VH;
        mtCnt = 1;
        lutCnt = 1;
        for rowCnt = 2 : rowNum
            if (rowStage(rowCnt) == stageCnt) 
                if (mtCnt < mtLut(lutCnt) + 1)
                    vrStart(rowCnt) = VW;
                else % OL
                    vrStart(rowCnt) = VG;
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        vrStart
        vrEnd = vrStart
        % vc
        vcStart = ones(1, colNum) * VH;
        % vx, bsw
        for colCnt = 1:colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2)==0)
                vcStart(colCnt) = vrStart * gMapStart(:, colCnt);
                vcStart(colCnt) = vcStart(colCnt) / (sum(gMapStart(:, colCnt)) + 1 / RS);
            end
        end
        % vx, asw
        vcEnd = ones(1, colNum) * VH;
        for colCnt = 1:colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2)==0)
                vcEnd(colCnt) = vrEnd * gMapEnd(:, colCnt);
                vcEnd(colCnt) = vcEnd(colCnt) / (sum(gMapEnd(:, colCnt)) + 1 / RS);
            end
        end
        vcStart
        vcEnd
        % power
        for rowCnt = 1 : rowNum
            for colCnt = 1 : colNum
                pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
                pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
                pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
                pGER = pGER + pDevice;
            end
        end
        pGERCell = pGER;
        % RS
        % row
        for rowCnt = 1 : rowNum
            pDeviceStart = vrStart(rowCnt)^2 / RS;
            pDeviceEnd = vrEnd(rowCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pGER = pGER + pDevice;
        end
        pGERRSRow = pGER - pGERCell;
        % col
        for colCnt = 1 : colNum
            pDeviceStart = vcStart(colCnt)^2 / RS;
            pDeviceEnd = vcEnd(colCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pGER = pGER + pDevice;
        end
        pGERRSCol = pGER - pGERCell - pGERRSRow;
        pGERCell
        pGERRSRow
        pGERRSCol
        pGER

        %---------- INR -----------
        % update data map for start and end
        % obtain gMapStart and gMapEnd
        % set the IL based on the input value
        % update data Map 
        mtCnt = 1;
        lutCnt = 1;
        dMapStart = dMapEnd;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 1) && (xl(rowCnt, colCnt))
                        if (dMapStart(rowCnt, colCnt + 1) == 0) && (mtCnt == mtLut(lutCnt) + 1)
                            dMapEnd(rowCnt, colCnt) = 1;
                        end   
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        dMapStart
        dMapEnd

        % update conductance map
        mtCnt = 1;
        lutCnt = 1;
        gMapStart = gMapEnd;
        for rowCnt = 2 : rowNum % skip the IL
            if rowStage(rowCnt) == stageCnt
                for colCnt = 1 : colNum
                    if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2) == 1) && (xl(rowCnt, colCnt))
                        if (dMapStart(rowCnt, colCnt + 1) == 1) && (mtCnt == mtLut(lutCnt) + 1)
                            gMapEnd(rowCnt, colCnt) = 1/RL;
                        end 
                    end
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        gMapStart;
        gMapEnd;

        % vc
        vcStart = ones(1, colNum) * VH;
        for colCnt = 1:colNum
            if (sigStage(ceil(colCnt/2)) == stageCnt) && (mod(colCnt,2)==1)
                vcStart(colCnt) = VW;
            end
        end
        vcStart;
        vcEnd = vcStart
        % vr
        vrStart = ones(1, rowNum) * VH;
        mtCnt = 1;
        lutCnt = 1;
        % vr, vx, bsw
        for rowCnt = 2 : rowNum
            if (rowStage(rowCnt) == stageCnt) 
                if (mtCnt == mtLut(lutCnt) + 1)
                    vrStart(rowCnt) = vcStart * gMapStart(rowCnt, :)';
                    vrStart(rowCnt) = vrStart(rowCnt) / (sum(gMapStart(rowCnt, :)) + 1 / RS);
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        vrStart
        % vr, vx, bsw
        vrEnd = ones(1, rowNum) * VH;
        mtCnt = 1;
        lutCnt = 1;
        for rowCnt = 2 : rowNum
            if (rowStage(rowCnt) == stageCnt) 
                if (mtCnt == mtLut(lutCnt) + 1)
                    vrEnd(rowCnt) = vcEnd * gMapEnd(rowCnt, :)';
                    vrEnd(rowCnt) = vrEnd(rowCnt) / (sum(gMapEnd(rowCnt, :)) + 1 / RS);
                end
            end
            if rowCnt >= 2
                if mtCnt < mtLut(lutCnt) + 1
                    mtCnt = mtCnt + 1;
                else
                    mtCnt = 1;
                    lutCnt = lutCnt + 1;
                end
            end
        end
        vrEnd
        % power
        for rowCnt = 1 : rowNum
            for colCnt = 1 : colNum
                pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
                pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
                pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
                pINR = pINR + pDevice;
            end
        end
        pINRCell = pINR;
        % RS
        % row
        for rowCnt = 1 : rowNum
            pDeviceStart = vrStart(rowCnt)^2 / RS;
            pDeviceEnd = vrEnd(rowCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pINR = pINR + pDevice;
        end
        pINRRSRow = pINR - pINRCell;
        % col
        for colCnt = 1 : colNum
            pDeviceStart = vcStart(colCnt)^2 / RS;
            pDeviceEnd = vcEnd(colCnt)^2 / RS;
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pINR = pINR + pDevice;
        end
        pINRRSCol = pINR - pINRCell - pINRRSRow;
        pINRCell
        pINRRSRow
        pINRRSCol
        pINR
    end % loop of stages
    %---------- INA -----------
    % update data map for start and end
    % obtain gMapStart and gMapEnd
    % set the IL based on the input value 
    % update conductance map
    gMapStart = gMapEnd;
    for rowCnt = 1 : rowNum % skip the IL
        for colCnt = 1 : colNum
            if xl(rowCnt, colCnt)
                gMapEnd(rowCnt, colCnt) = 1/RH;
            end
        end
    end
    gMapStart;
    gMapEnd;
    
    % vc
    vcStart = ones(1, colNum) * VG;
    vcEnd = vcStart   
    % vr
    vrStart = ones(1, rowNum) * VW;
    vrEnd = vrStart
    % power
    for rowCnt = 1 : rowNum
        for colCnt = 1 : colNum
            pDeviceStart = (vrStart(rowCnt) - vcStart(colCnt))^2 * gMapStart(rowCnt, colCnt);
            pDeviceEnd = (vrEnd(rowCnt) - vcEnd(colCnt))^2 * gMapEnd(rowCnt, colCnt);
            pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
            pINA = pINA + pDevice;
        end
    end
    pINACell = pINA;
    % RS
    % row
    for rowCnt = 1 : rowNum
        pDeviceStart = vrStart(rowCnt)^2 / RS;
        pDeviceEnd = vrEnd(rowCnt)^2 / RS;
        pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
        pINA = pINA + pDevice;
    end
    pINARSRow = pINA - pINACell;
    % col
    for colCnt = 1 : colNum
        pDeviceStart = vcStart(colCnt)^2 / RS;
        pDeviceEnd = vcEnd(colCnt)^2 / RS;
        pDevice = 0.5 * (pDeviceStart + pDeviceEnd);
        pINA = pINA + pDevice;
    end
    pINARSCol = pINA - pINACell - pINARSRow;
    pINACell
    pINARSRow
    pINARSCol
    pINA
    
    % statistics
    % state by state
    pRIN
    pCFM
    pEVM
    pGER
    pINR
    pINA
    % total
    pTotal = 0;
    pTotal = pTotal + pRIN;
    pTotal = pTotal + pCFM;
    pTotal = pTotal + pEVM;
    pTotal = pTotal + pGER;
    pTotal = pTotal + pINR;
    pTotal = pTotal + pINA;
    pTotal
    % percentage by state
    perRIN = pRIN / pTotal * 100
    perCFM = pCFM / pTotal * 100
    perEVM = pEVM / pTotal * 100
    perGER = pGER / pTotal * 100
    perINR = pINR / pTotal * 100
    perINA = pINA / pTotal * 100
    % cell vs RS
    pCell = 0;
    pCell = pCell + pRINCell;
    pCell = pCell + pCFMCell;
    pCell = pCell + pEVMCell;
    pCell = pCell + pGERCell;
    pCell = pCell + pINRCell;
    pCell = pCell + pINACell
    pRS = 0;
    pRS = pRS + pRINRSRow + pRINRSCol;
    pRS = pRS + pCFMRSRow + pCFMRSCol;
    pRS = pRS + pEVMRSRow + pEVMRSCol;
    pRS = pRS + pGERRSRow + pGERRSCol;
    pRS = pRS + pINRRSRow + pINRRSCol;
    pRS = pRS + pINARSRow + pINARSCol
    % percentage by cell & RS
    perRINCell = pRINCell / pTotal * 100;
    perCFMCell = pCFMCell / pTotal * 100;
    perEVMCell = pEVMCell / pTotal * 100;
    perGERCell = pGERCell / pTotal * 100;
    perINRCell = pINRCell / pTotal * 100;
    perINACell = pINACell / pTotal * 100;
    perCell = pCell / pTotal * 100
    
    perRINRS = (pRINRSRow + pRINRSCol)  / pTotal * 100;
    perCFMRS = (pCFMRSRow + pCFMRSCol) / pTotal * 100;
    perEVMRS = (pEVMRSRow + pEVMRSCol) / pTotal * 100;
    perGERRS = (pGERRSRow + pGERRSCol) / pTotal * 100;
    perINRRS = (pINRRSRow + pINRRSCol) / pTotal * 100;
    perINARS = (pINARSRow + pINARSCol) / pTotal * 100;
    perRS = pRS / pTotal * 100
    % avg states
    pRINAvg = pRINAvg + pRIN;
    pCFMAvg = pCFMAvg + pCFM;
    pEVMAvg = pEVMAvg + pEVM;
    pGERAvg = pGERAvg + pGER;
    pINRAvg = pINRAvg + pINR;
    pINAAvg = pINAAvg + pINA;
end  % input loop
% avg state
pRINAvg = pRINAvg / nPossibleInput
pCFMAvg = pCFMAvg / nPossibleInput
pEVMAvg = pEVMAvg / nPossibleInput
pGERAvg = pGERAvg / nPossibleInput
pINRAvg = pINRAvg / nPossibleInput
pINAAvg = pINAAvg / nPossibleInput
pTotalAvg = 0;
pTotalAvg = pTotalAvg + pRINAvg;
pTotalAvg = pTotalAvg + pCFMAvg;
pTotalAvg = pTotalAvg + pEVMAvg;
pTotalAvg = pTotalAvg + pGERAvg;
pTotalAvg = pTotalAvg + pINRAvg;
pTotalAvg = pTotalAvg + pINAAvg
perRINAvg = pRINAvg / pTotalAvg * 100
perCFMAvg = pCFMAvg / pTotalAvg * 100
perEVMAvg = pEVMAvg / pTotalAvg * 100
perGERAvg = pGERAvg / pTotalAvg * 100
perINRAvg = pINRAvg / pTotalAvg * 100
perINAAvg = pINAAvg / pTotalAvg * 100
elapsedtime = toc % measure the elpased time